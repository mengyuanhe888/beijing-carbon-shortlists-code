# Reported results

We provide CSV versions of Tables 3–5 and Supplementary Tables S1 and S3 from *Sensitivity and stability of subdistrict carbon-emission shortlists under district-level statistical constraints: Evidence from Beijing*.

These files contain reported findings. The processed model panel and full study inputs are supplied separately; these result tables are not inputs for model estimation.

## Files

| File | Contents |
|---|---|
| Table3.csv | District-level fit and holdout statistics. The LODO mean and median occupy separate rows. |
| Table4.csv | All six comparisons reported in Table 4, with their constraints and time periods. |
| Table5.csv | Electricity-and-heat reallocation bounds in 2022, with fixed district totals. |
| TableS1.csv | The 73-subdistrict union of the M4, M4′ and EDGAR product top-35 lists in 2022, including ranks, membership and selection frequencies. |
| TableS3.csv | Stability tiers of the 2022 M4 top 35 and selection in all three comparison scenarios. |

Main-table values use the manuscript's reported precision. Supplementary CSVs retain their original numerical precision. All files use UTF-8 encoding and a single header row. Blank main-table cells mean not reported or not applicable, not zero.

## Units and definitions

- **Table 3:** correlations and L1 distances are dimensionless. MAE is in percentage points. Full-sample and LOYO statistics are annual means for 2016–2022. LODO correlations describe seven-year variation within each held-out district, with their mean and median taken across districts. The count of districts with q < 0.10 is 0 out of 16. Joint holdout MAE pools 112 district–year observations after normalizing shares within each held-out four-district group. M1 and M3 denote the uncalibrated nighttime-light and multisource models.
- **Table 4:** every comparator is compared with M4. Correlations and mean top-35 overlap refer to 2016–2022, except the ODIAC correlation, which refers to 2022. Overlap values are percentages (20.8 means 20.8%). Shared-member counts refer to the 2022 lists of 35 subdistricts. M4prime denotes M4′. External-product comparisons and electricity-and-heat reallocation scenarios are distinct rows.
- **Table 5:** percentages use total citywide electricity and heat emissions as the denominator. Citywide and district emission totals are fixed. EDGAR and ODIAC supply all-sector spatial templates, not observations of electricity-and-heat facility locations. These bounds describe spatial reallocation, not emission reductions.

## Supplementary shortlist fields

Table S1 uses the study's subdistrict identifiers; read street_id as an identifier, not as a measurement. street_name and district_name use the English names in the Supplementary Material. unit_type distinguishes subdistricts, towns and townships.

M4_rank, M4prime_rank and EDGAR_rank are ranks among the original 343 subdistricts in 2022; 1 is the highest allocation. The corresponding *_selected fields indicate top-35 membership. EDGAR_rank and EDGAR_selected refer to the external product, whereas EDGAR_scenario_selected and ODIAC_scenario_selected refer to full electricity-and-heat reallocation scenarios.

bootstrap_frequency is a proportion from 0 to 1, with all 1,000 continued_all resamples in the denominator. Of the saved fits, 998 reported convergence. frequency_layer records the selection-frequency tier. cross_setting_count counts top-35 selection in baseline M4, M4′ and the two electricity-and-heat scenarios, giving four settings in total. triple_union identifies membership in the union of M4, M4′ and EDGAR product lists. membership names those lists.

Among the 35 baseline M4 members, high-frequency candidates have selection frequencies of at least 80%; secondary candidates have frequencies from 50% to less than 80%; sample-sensitive members have frequencies below 50%. Table S3 reports all three tiers. Core candidates meet the high-frequency criterion and enter the top 35 in all three comparison scenarios: seven of the eight high-frequency candidates meet both conditions. These frequencies describe selection under the study's resampling procedure.
