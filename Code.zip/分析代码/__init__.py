"""Subdistrict emission allocation with a consistent nighttime-light window."""
