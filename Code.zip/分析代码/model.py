"""Model input, saved-coefficient prediction, and full-sample estimation.

The calculations are defined in core.py. Internal columns w_m0 through w_m4
correspond to paper models M1, M2, M3, M4, and M4-prime, respectively."""
from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
import time

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .core import (
    ALL_TERMS, STANDARDIZED_TERMS, ExactObjective, Scaler, linear_corr,
    make_scaler, predict_all_models, rank_corr,
)


PANEL_COLUMNS = [
    "year", "street_id", "street_name", "district_code", "district_name",
    "area_km2", "ntl_sum", "w_ntl_m0", "city_total",
    "energy_consumption_10k_tce", "electricity_10k_kwh",
    "energy_share_16district", "elec_share_16district", "building_density",
    "street_road_density", "poi_density", "green_ratio", "industrial_ratio",
    "commercial_ratio", "residential_ratio", "log_ntl", "log_poi_density",
    "log_road_density", "log_building_density",
]


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def load_panel(path: str | Path) -> pd.DataFrame:
    """Load the 2016–2022 processed panel and validate its keys, coverage, and input transformations without changing row order."""
    frame = pd.read_csv(path, float_precision="round_trip")
    _require(set(frame.columns) == set(PANEL_COLUMNS), "The panel must contain the specified 24 columns")
    _require(not frame.isna().any().any(), "The panel contains missing values")
    numeric = frame.drop(columns=["street_name", "district_name"])
    _require(np.isfinite(numeric.to_numpy(dtype=float)).all(), "The panel contains non-finite values")
    _require(len(frame) == 2401, "The panel must contain 2,401 subdistrict-year records")
    _require(not frame.duplicated(["year", "street_id"]).any(), "Duplicate subdistrict-year keys")
    _require(set(frame.year) == set(range(2016, 2023)), "The study years must be 2016–2022")
    _require(frame.street_id.nunique() == 343, "The panel must contain 343 subdistricts")
    _require(frame.district_name.nunique() == 16, "The panel must contain 16 districts")
    _require(frame.groupby("year").street_id.nunique().eq(343).all(), "Each year must contain all 343 subdistricts")
    _require(frame.groupby("street_id").year.nunique().eq(7).all(), "Each subdistrict must have seven annual records")
    fixed = ["street_name", "district_code", "district_name", "area_km2",
             "building_density", "street_road_density", "poi_density",
             "green_ratio", "industrial_ratio", "commercial_ratio", "residential_ratio"]
    _require(frame.groupby("street_id")[fixed].nunique().eq(1).all().all(),
             "Subdistrict attributes, district assignments, and seven snapshot variables must be constant across years")
    _require(frame.groupby("district_name").district_code.nunique().eq(1).all()
             and frame.groupby("district_code").district_name.nunique().eq(1).all(),
             "District codes and names must have a one-to-one correspondence")
    _require((frame[["area_km2", "city_total"]] > 0).all().all(), "Areas and citywide totals must be positive")
    nonnegative = ["ntl_sum", "building_density", "street_road_density", "poi_density",
                   "energy_consumption_10k_tce", "electricity_10k_kwh",
                   "green_ratio", "industrial_ratio", "commercial_ratio", "residential_ratio"]
    _require((frame[nonnegative] >= 0).all().all(), "Counts, densities, and area ratios must be nonnegative")
    _require(frame.groupby("year").city_total.nunique().eq(1).all(), "Citywide totals differ within a year")
    district_fields = ["energy_consumption_10k_tce", "electricity_10k_kwh",
                       "energy_share_16district", "elec_share_16district"]
    grouped = frame.groupby(["year", "district_name"])
    _require(grouped[district_fields].nunique().eq(1).all().all(), "District statistics differ within a district-year")
    districts = grouped[district_fields].first()
    _require(districts.groupby(level=0).size().eq(16).all(), "Each year must contain all 16 districts")
    for raw, share in [("energy_consumption_10k_tce", "energy_share_16district"),
                       ("electricity_10k_kwh", "elec_share_16district")]:
        totals = districts[raw].groupby(level=0).transform("sum")
        _require((totals > 0).all(), f"The annual sum across districts must be positive: {raw}")
        _require(np.allclose(districts[share], districts[raw] / totals, rtol=0, atol=1e-12),
                 f"District shares differ from those calculated from the totals: {share}")
    light_totals = frame.groupby("year").ntl_sum.transform("sum")
    _require((light_totals > 0).all(), "Annual nighttime-light totals must be positive")
    _require((grouped.ntl_sum.sum() > 0).all(), "Within-district normalization requires positive nighttime-light totals in every district")
    _require(np.allclose(frame.w_ntl_m0, frame.ntl_sum / light_totals, rtol=0, atol=1e-12),
             "Saved nighttime-light weights differ from annual normalized shares")
    for derived, raw, scale in [("log_ntl", "ntl_sum", 1.0),
                                ("log_poi_density", "poi_density", 1.0),
                                ("log_road_density", "street_road_density", 1.0),
                                ("log_building_density", "building_density", 1000.0)]:
        _require(np.allclose(frame[derived], np.log1p(scale * frame[raw]), rtol=0, atol=1e-12),
                 f"Saved transformed variables differ from calculated values: {derived}")
    return frame


def _validate_parameters(parameters: dict) -> tuple[np.ndarray, Scaler]:
    beta = np.asarray(parameters["beta"], dtype=float)
    _require(beta.shape == (len(ALL_TERMS),) and np.isfinite(beta).all(), "Eight finite coefficients are required")
    scaler = Scaler(**parameters["scaler"])
    _require(set(scaler.means) == set(STANDARDIZED_TERMS)
             and set(scaler.stds) == set(STANDARDIZED_TERMS), "Standardization parameters must cover all seven non-light variables")
    _require(scaler.ddof == 0, "Standardization uses population standard deviations (ddof=0)")
    _require(np.isfinite(list(scaler.means.values())).all(), "Standardization means must be finite")
    sd = np.asarray(list(scaler.stds.values()), dtype=float)
    _require(np.isfinite(sd).all() and (sd > 0).all(), "Standardization standard deviations must be finite and positive")
    return beta, scaler


def saved_parameters(cfg: dict) -> tuple[np.ndarray, Scaler]:
    """Read the selected coefficients and full-sample standardization parameters."""
    return _validate_parameters({
        "beta": cfg["full_sample"]["selected_endpoint"]["end_vector"],
        "scaler": cfg["full_sample"]["scaler"],
    })


def load_parameters(path: str | Path) -> tuple[np.ndarray, Scaler]:
    """Read parameters.json from a fit or saved-coefficient prediction run."""
    return _validate_parameters(json.loads(Path(path).read_text(encoding="utf-8")))


def load_config(path: str | Path) -> dict:
    """Read and validate the study configuration."""
    cfg = json.loads(Path(path).read_text(encoding="utf-8"))
    _require(cfg["terms"] == ALL_TERMS, "Model variables or their order differ from the study configuration")
    _require(cfg["lambda_N"] == 0.0 and cfg["lambda_R"] == 1e-4,
             "Regularization parameters differ from the study configuration")
    _require(cfg["parameter_bounds"] is None, "The study model uses unbounded coefficients")
    starts = np.asarray(cfg["full_sample"]["initial_vectors"], dtype=float)
    _require(starts.shape == (20, 8) and np.isfinite(starts).all(), "Twenty initialization vectors with eight finite coefficients each are required")
    methods = cfg["full_sample"]["optimizers"]
    _require(list(methods) == ["L-BFGS-B", "Powell", "Nelder-Mead"], "The optimizer list or order differs from the study configuration")
    saved_parameters(cfg)
    return cfg


def replay(frame: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    """Calculate all five allocation schemes using the saved coefficients."""
    beta, scaler = saved_parameters(cfg)
    return predict_all_models(frame, beta, scaler)


def district_metrics(frame: pd.DataFrame, weights: np.ndarray,
                     mask: np.ndarray | None = None) -> dict[str, float]:
    """Calculate district fit metrics and average them with equal weight across years."""
    use = np.ones(len(frame), dtype=bool) if mask is None else np.asarray(mask, dtype=bool)
    _require(use.shape == (len(frame),), "The metric mask has an incompatible length")
    w = np.asarray(weights, dtype=float)
    _require(w.shape == (len(frame),) and np.isfinite(w).all(), "The weight vector has an incompatible length or non-finite values")
    tmp = frame.loc[use, ["year", "district_name", "energy_share_16district"]].copy()
    tmp["pred"] = w[use]
    agg = tmp.groupby(["year", "district_name"], as_index=False).agg(
        target=("energy_share_16district", "first"), pred=("pred", "sum"))
    annual = []
    for year, gy in agg.groupby("year"):
        annual.append({
            "year": int(year), "spearman": rank_corr(gy.pred, gy.target),
            "pearson": linear_corr(gy.pred, gy.target),
            "l1": float(np.abs(gy.pred - gy.target).sum()),
            "mae": float(np.abs(gy.pred - gy.target).mean()),
        })
    a = pd.DataFrame(annual)
    _require(not a.empty, "No district-year records are available for evaluation")
    return {f"mean_{c}": float(a[c].mean()) for c in ["spearman", "pearson", "l1", "mae"]}


def fit(frame: pd.DataFrame, cfg: dict, outdir: str | Path) -> pd.DataFrame:
    """Estimate the full-sample model from 20 starts and three optimizers.

    We select the endpoint with the lowest finite objective from all 60 runs,
    including endpoints that do not report convergence. Non-finite coefficients
    or objectives stop the run. This function estimates coefficients from the
    input panel; replay uses the saved coefficients."""
    outdir = Path(outdir)
    names = ["optimizer_endpoints.jsonl", "parameters.json", "model_panel.csv"]
    _require(not any((outdir / name).exists() for name in names),
             "Output files already exist; a new output directory is required")
    outdir.mkdir(parents=True, exist_ok=True)
    scaler = make_scaler(frame, scope="full_sample")
    objective = ExactObjective(frame, terms=cfg["terms"], scaler=scaler,
                               lambda_n=cfg["lambda_N"], lambda_r=cfg["lambda_R"])
    rows = []
    with (outdir / names[0]).open("x", encoding="utf-8") as log:
        for method, options in cfg["full_sample"]["optimizers"].items():
            for i, start in enumerate(cfg["full_sample"]["initial_vectors"], 1):
                started = time.monotonic()
                result = minimize(objective, np.asarray(start, dtype=float),
                                  method=method, options=dict(options))
                row = {
                    "run_id": f"{method}_{i:02d}", "optimizer": method,
                    "start_vector": start, "end_vector": result.x.tolist(),
                    "success": bool(result.success), "message": str(result.message),
                    "iterations": int(getattr(result, "nit", -1)),
                    "function_evaluations": int(getattr(result, "nfev", -1)),
                    "runtime_seconds": time.monotonic() - started,
                    **objective.objective_parts(result.x),
                }
                _require(np.isfinite(row["exact_objective"]) and np.isfinite(result.x).all(),
                         f"The optimization endpoint contains non-finite values: {row['run_id']}")
                rows.append(row)
                log.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                log.flush()
    chosen = min(rows, key=lambda row: row["exact_objective"])
    beta = np.asarray(chosen["end_vector"], dtype=float)
    output = predict_all_models(frame, beta, scaler)
    output.to_csv(outdir / "model_panel.csv", index=False, encoding="utf-8",
                  lineterminator="\n", float_format="%.17g")
    parameters = {"beta": beta.tolist(), "scaler": asdict(scaler), "source": "refit",
                  "selected_endpoint": chosen}
    (outdir / "parameters.json").write_text(
        json.dumps(parameters, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8")
    return output
