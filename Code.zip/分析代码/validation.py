"""LOYO, LODO, variable-configuration, and joint spatial–temporal analyses.

We estimate standardization parameters from each training sample. LODO
significance is evaluated with exact permutations of the seven annual ranks."""
from __future__ import annotations

from functools import lru_cache
from itertools import permutations
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import rankdata

from .core import ALL_TERMS, ExactObjective, linear_corr, make_scaler, rank_corr
from .estimation import (
    append_jsonl, endpoint_details, fit_candidates, require_new_output,
    save_csv, save_json,
)


BLOCKS = {
    "M-A NTL": ["log_ntl"],
    "M-B NTL+green": ["log_ntl", "green_ratio"],
    "M-C NTL+green+building+road": ["log_ntl", "green_ratio", "log_building_density", "log_road_density"],
    "M-D full": ALL_TERMS,
    "M-E full-green": [term for term in ALL_TERMS if term != "green_ratio"],
}


def ordered_panel(frame: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    if list(cfg["terms"]) != ALL_TERMS:
        raise ValueError("Configuration variables or their order differ from model inputs")
    out = frame.copy()
    out["street_id"] = out.street_id.astype(str)
    out = out.sort_values(["year", "street_id"], kind="mergesort").reset_index(drop=True)
    if out.duplicated(["year", "street_id"]).any():
        raise ValueError("Duplicate subdistrict-year records")
    if out.year.unique().tolist() != list(range(2016, 2023)) or out.street_id.nunique() != 343 or len(out) != 2401:
        raise ValueError("A balanced panel of 343 subdistricts over seven years is required")
    if not out.groupby("street_id").year.nunique().eq(7).all():
        raise ValueError("Incomplete seven-year records for a subdistrict")
    return out


def district_fit_metrics(panel, weights, mask=None):
    use = np.ones(len(panel), dtype=bool) if mask is None else np.asarray(mask, dtype=bool)
    tmp = panel.loc[use, ["year", "district_name", "energy_share_16district"]].copy()
    tmp["pred"] = np.asarray(weights)[use]
    aggregate = tmp.groupby(["year", "district_name"], as_index=False).agg(
        target=("energy_share_16district", "first"), pred=("pred", "sum")
    )
    annual = []
    for _, group in aggregate.groupby("year"):
        annual.append({
            "spearman": rank_corr(group.pred, group.target),
            "pearson": linear_corr(group.pred, group.target),
            "l1": float(np.abs(group.pred - group.target).sum()),
            "mae": float(np.abs(group.pred - group.target).mean()),
        })
    metrics = pd.DataFrame(annual)
    return {f"mean_{name}": float(metrics[name].mean()) for name in metrics}


def bh_adjust(values):
    p = np.asarray(values, dtype=float)
    out = np.full(p.shape, np.nan)
    valid = np.isfinite(p)
    v = p[valid]
    order = np.argsort(v)
    adjusted = np.minimum.accumulate((v[order] * len(v) / np.arange(1, len(v) + 1))[::-1])[::-1]
    restored = np.empty_like(adjusted)
    restored[order] = np.clip(adjusted, 0, 1)
    out[valid] = restored
    return out


@lru_cache(maxsize=1)
def _seven_year_permutations():
    return np.array(list(permutations(range(7))), dtype=int)


def exact_seven_year_pvalue(prediction, target):
    """Calculate a two-sided exact Spearman p-value over all 7! permutations.

    Both vectors are ranked before permutation to account for ties. The study's
    LODO sequences contain no tied values."""
    x, y = np.asarray(prediction, dtype=float), np.asarray(target, dtype=float)
    if len(x) != 7 or len(y) != 7 or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("The LODO exact test requires seven finite annual observations")
    xr, yr = rankdata(x), rankdata(y)
    xr -= xr.mean()
    yr -= yr.mean()
    denominator = np.linalg.norm(xr) * np.linalg.norm(yr)
    if denominator == 0:
        return float("nan")
    observed = float(xr @ yr / denominator)
    null = yr[_seven_year_permutations()] @ xr / denominator
    return float(np.mean(np.abs(null) >= abs(observed) - 1e-15))


def run_holdout(frame, cfg, beta, outdir):
    panel = ordered_panel(frame, cfg)
    dest = require_new_output(Path(outdir) / "holdout")
    options = cfg["LOYO_LODO"]["options"]
    rows = []
    for kind, values in [("LOYO", sorted(panel.year.unique())), ("LODO", sorted(panel.district_name.unique()))]:
        for held in values:
            mask = panel.year.to_numpy() != held if kind == "LOYO" else panel.district_name.to_numpy() != held
            scaler = make_scaler(panel, mask, scope=f"{kind}_excluding_{held}")
            primary, sensitivity, _ = fit_candidates(
                panel, cfg, ALL_TERMS, scaler, mask, beta, options, f"{kind}_{held}", dest / "endpoints.jsonl"
            )
            for mode, chosen in [("primary_zero_NTL1", primary), ("sensitivity_including_parent", sensitivity)]:
                weights = ExactObjective(panel, scaler=scaler).weights(chosen["end_vector"])
                row = {
                    "kind": kind, "heldout": str(held), "mode": mode,
                    "chosen_initialization": chosen["initialization"], "success": chosen["success"],
                    "objective": chosen["exact_objective"],
                }
                if kind == "LOYO":
                    row.update(district_fit_metrics(panel, weights, ~mask))
                else:
                    yearly = panel.assign(weight=weights).loc[~mask].groupby("year").agg(
                        pred=("weight", "sum"), target=("energy_share_16district", "first")
                    )
                    row.update(spearman=rank_corr(yearly.pred, yearly.target), exact_p=exact_seven_year_pvalue(yearly.pred, yearly.target))
                rows.append(row)
            print(kind, held, flush=True)
    results = pd.DataFrame(rows)
    for mode in results["mode"].unique():
        index = results.kind.eq("LODO") & results["mode"].eq(mode)
        results.loc[index, "exact_q"] = bh_adjust(results.loc[index, "exact_p"])
    save_csv(results, dest / "metrics.csv")
    summary = {
        "LOYO": results[results.kind.eq("LOYO")].groupby("mode")[["mean_spearman", "mean_l1"]].mean().to_dict(),
        "LODO": {
            mode: {"mean": float(group.spearman.mean()), "median": float(group.spearman.median()), "q_lt_0_1": int((group.exact_q < .1).sum())}
            for mode, group in results[results.kind.eq("LODO")].groupby("mode")
        },
    }
    save_json(summary, dest / "summary.json")
    return summary


def run_blocks(frame, cfg, beta, outdir):
    from statsmodels.stats.outliers_influence import variance_inflation_factor

    panel = ordered_panel(frame, cfg)
    dest = require_new_output(Path(outdir) / "blocks")
    full, loyo = [], []
    for name, terms in BLOCKS.items():
        parent = np.asarray([beta[ALL_TERMS.index(term)] for term in terms])
        scaler = make_scaler(panel, scope="full_sample")
        _, chosen, _ = fit_candidates(
            panel, cfg, terms, scaler, None, parent, {"maxiter": 450, "ftol": 1e-11, "maxls": 40},
            name + "_full", dest / "endpoints.jsonl",
        )
        fitted = np.asarray(chosen["end_vector"])
        full.append({
            "block": name, "terms": "+".join(terms), "objective": chosen["exact_objective"],
            **district_fit_metrics(panel, ExactObjective(panel, terms=terms, scaler=scaler).weights(fitted)),
            "beta_vector": fitted.tolist(),
        })
        for held in sorted(panel.year.unique()):
            mask = panel.year.to_numpy() != held
            scaler = make_scaler(panel, mask, scope=f"block_training_excluding_{held}")
            primary, sensitivity, _ = fit_candidates(
                panel, cfg, terms, scaler, mask, fitted, {"maxiter": 300, "ftol": 1e-11, "maxls": 40},
                f"{name}_{held}", dest / "endpoints.jsonl",
            )
            for mode, candidate in [("primary_zero_NTL1", primary), ("sensitivity_including_parent", sensitivity)]:
                weights = ExactObjective(panel, terms=terms, scaler=scaler).weights(candidate["end_vector"])
                loyo.append({
                    "block": name, "heldout_year": int(held), "mode": mode,
                    "initialization": candidate["initialization"], **district_fit_metrics(panel, weights, ~mask),
                })
        print(name, "complete", flush=True)
    save_csv(pd.DataFrame(full), dest / "full_sample.csv")
    save_csv(pd.DataFrame(loyo), dest / "loyo.csv")
    matrix = make_scaler(panel, scope="full").transform(panel, ALL_TERMS)
    save_csv(pd.DataFrame({"variable": ALL_TERMS, "VIF": [variance_inflation_factor(matrix, i) for i in range(len(ALL_TERMS))]}), dest / "vif.csv")
    summary = {"variable_blocks": 5, "all_blocks_refitted": True, "loyo_primary_starts": ["zero", "NTL1"]}
    save_json(summary, dest / "summary.json")
    return summary


def make_training_objective(panel, cfg, fold):
    mask = (~panel.district_name.isin(fold["held_districts"]) & ~panel.year.isin(fold["held_years"])).to_numpy()
    scaler = make_scaler(panel.loc[mask], scope=f"strict_train_{fold['fold_id']}")
    # Set held-out features and targets to missing to check their exclusion from training.
    visible = panel.copy()
    visible.loc[~mask, ALL_TERMS + ["energy_share_16district", "w_ntl_m0"]] = np.nan
    objective = ExactObjective(
        visible, train_mask=mask, scaler=scaler, strict_subset=True,
        lambda_n=cfg["lambda_N"], lambda_r=cfg["lambda_R"],
    )
    if len(objective.work) != int(mask.sum()) or objective.work[ALL_TERMS + ["energy_share_16district"]].isna().any().any():
        raise AssertionError("The joint training subset is incomplete or contains held-out records")
    return objective, scaler, mask


def evaluate_year(frame, raw_m3, districts, fold, year, scope):
    yearly = frame.loc[frame.year.eq(year)].copy()
    yearly["m3_raw"] = raw_m3[frame.year.eq(year).to_numpy()]
    yearly["m1_raw"] = yearly.ntl_sum.clip(lower=0)
    for model, raw in [("M1", "m1_raw"), ("M3", "m3_raw")]:
        denominator = float(yearly[raw].sum())
        if denominator <= 0:
            raise ValueError("Annual prediction normalization denominators must be positive")
        yearly[model] = yearly[raw] / denominator
    target = yearly.groupby("district_name").energy_share_16district.first().loc[districts]
    if scope == "conditional":
        target = target / float(target.sum())
    rows, metrics = [], []
    for model in ["M1", "M3"]:
        prediction = yearly.groupby("district_name")[model].sum().loc[districts]
        if scope == "conditional" and (abs(prediction.sum() - 1) >= 1e-12 or abs(target.sum() - 1) >= 1e-12):
            raise AssertionError("Conditional shares do not sum to one")
        common = {
            "fold_id": fold["fold_id"], "group_id": fold["group_id"], "year_block_id": fold["year_block_id"],
            "year": int(year), "model": model, "held_district_count": len(districts),
        }
        metrics.append({
            **common, "mae": float(np.abs(prediction - target).mean()), "spearman": rank_corr(prediction, target),
            "target_group_sum": float(target.sum()), "predicted_group_sum": float(prediction.sum()), "normalization_scope": scope,
        })
        for district, pred, truth in zip(districts, prediction, target):
            rows.append({**common, "district_name": district, "target_share": float(truth), "predicted_share": float(pred), "absolute_error": float(abs(pred - truth)), "normalization_scope": scope})
    return rows, metrics


def evaluate_fold(panel, fold, beta, scaler):
    group_mask, year_mask = panel.district_name.isin(fold["held_districts"]), panel.year.isin(fold["held_years"])
    outputs = []
    for scope, subset in [("conditional", panel.loc[group_mask & year_mask]), ("fullcity", panel.loc[year_mask])]:
        raw = np.exp(np.clip(scaler.transform(subset, ALL_TERMS) @ beta, -30.0, 30.0))
        rows, metrics = [], []
        for year in fold["held_years"]:
            a, b = evaluate_year(subset, raw, fold["held_districts"], fold, year, scope)
            rows.extend(a)
            metrics.extend(b)
        outputs.extend([rows, metrics])
    return tuple(outputs)


def run_joint(frame, cfg, beta, outdir):
    """Run joint holdout fits from three prespecified starts; beta is not used in this design."""
    panel = ordered_panel(frame, cfg)
    design = cfg["joint_holdout"]
    groups, blocks = design["district_groups"], design["year_blocks"]
    assigned = [name for group in groups for name in group["district_names_in_code"]]
    years = [year for block in blocks for year in block["years"]]
    if sorted(assigned) != sorted(panel.district_name.unique()) or sorted(years) != sorted(panel.year.unique()):
        raise ValueError("Joint district and year groups must cover all records without duplication")
    if len(groups) * len(blocks) != design["fold_count"] or design["fold_count"] != 12:
        raise ValueError("The joint design requires the 12 specified folds")
    dest = require_new_output(Path(outdir) / "joint")
    conditional_rows, conditional_years, fullcity_rows, fullcity_years, selected = [], [], [], [], []
    options = {key: design["optimizer"][key] for key in ["maxiter", "ftol", "maxls"]}
    for group in groups:
        for block in blocks:
            fold = {
                "fold_id": group["id"] + "_" + block["id"], "group_id": group["id"], "year_block_id": block["id"],
                "held_districts": group["district_names_in_code"], "held_years": block["years"],
            }
            objective, scaler, _ = make_training_objective(panel, cfg, fold)
            candidates = []
            for start in design["starts"]:
                fit = minimize(objective, np.asarray(start["beta"]), method="L-BFGS-B", options=options)
                row = endpoint_details(fit, objective, start["beta"], **fold, start_id=start["id"], scaler_means=scaler.means, scaler_stds=scaler.stds, options=options)
                candidates.append(row)
                append_jsonl(row, dest / "endpoints.jsonl")
            chosen = min(candidates, key=lambda item: item["exact_objective"])
            selected.append(chosen)
            a, b, c, d = evaluate_fold(panel, fold, np.asarray(chosen["end_vector"]), scaler)
            conditional_rows.extend(a); conditional_years.extend(b); fullcity_rows.extend(c); fullcity_years.extend(d)
            print("Joint fold", fold["fold_id"], flush=True)
    for name, rows in [
        ("conditional_district.csv", conditional_rows), ("conditional_year.csv", conditional_years),
        ("fullcity_district.csv", fullcity_rows), ("fullcity_year.csv", fullcity_years), ("selected_endpoints.csv", selected),
    ]:
        save_csv(pd.DataFrame(rows), dest / name)
    annual = pd.DataFrame(conditional_years)
    folds = annual.groupby(["fold_id", "group_id", "year_block_id", "model"]).agg(
        mae_mean=("mae", "mean"), spearman_mean=("spearman", "mean"), test_year_count=("year", "nunique")
    ).reset_index()
    save_csv(folds, dest / "conditional_fold.csv")
    summary = {
        "conditional_district_MAE": annual.groupby("model").mae.mean().to_dict(),
        "equal_fold_MAE": folds.groupby("model").mae_mean.mean().to_dict(),
        "folds": len(selected), "starts_per_fold": len(design["starts"]),
        "training_excludes_held_districts_and_held_years": True,
        "reported_MAE_weighting": "112 held-out district-years per model, not equal weighting of 12 folds",
    }
    save_json(summary, dest / "summary.json")
    return summary


def run_validation(frame, cfg, beta, outdir):
    return {
        "holdout": run_holdout(frame, cfg, beta, outdir),
        "blocks": run_blocks(frame, cfg, beta, outdir),
        "joint": run_joint(frame, cfg, beta, outdir),
    }
