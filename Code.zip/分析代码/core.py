from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import pearsonr, spearmanr


ALL_TERMS = [
    "log_ntl",
    "log_poi_density",
    "log_road_density",
    "log_building_density",
    "green_ratio",
    "industrial_ratio",
    "commercial_ratio",
    "residential_ratio",
]
STANDARDIZED_TERMS = ALL_TERMS[1:]
LAMBDA_N = 0.0
LAMBDA_R = 1e-4
RANDOM_SEED = 20260814


def rank_corr(x: Sequence[float], y: Sequence[float]) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3 or np.unique(x[ok]).size < 2 or np.unique(y[ok]).size < 2:
        return float("nan")
    return float(spearmanr(x[ok], y[ok]).statistic)


def linear_corr(x: Sequence[float], y: Sequence[float]) -> float:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3 or np.unique(x[ok]).size < 2 or np.unique(y[ok]).size < 2:
        return float("nan")
    return float(pearsonr(x[ok], y[ok]).statistic)


def gini(values: Sequence[float]) -> float:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan")
    if np.any(x < 0):
        raise ValueError("Gini coefficients require nonnegative values")
    total = x.sum()
    if total <= 0:
        return 0.0
    x = np.sort(x)
    n = x.size
    return float((2.0 * np.dot(np.arange(1, n + 1), x) / (n * total)) - (n + 1.0) / n)


def top_ids(df: pd.DataFrame, value_col: str, k: int) -> set[str]:
    ranked = df.assign(_id=df["street_id"].astype(str)).sort_values(
        [value_col, "_id"], ascending=[False, True], kind="mergesort"
    )
    return set(ranked.head(k)["_id"])


@dataclass(frozen=True)
class Scaler:
    means: dict[str, float]
    stds: dict[str, float]
    scope: str
    ddof: int = 0

    def transform(self, frame: pd.DataFrame, terms: Sequence[str]) -> np.ndarray:
        cols: list[np.ndarray] = []
        for term in terms:
            x = frame[term].to_numpy(dtype=float)
            if term == "log_ntl":
                cols.append(x)
            else:
                sd = self.stds[term]
                cols.append((x - self.means[term]) / (sd if sd else 1.0))
        return np.column_stack(cols)


def make_scaler(frame: pd.DataFrame, mask: np.ndarray | pd.Series | None = None, *, scope: str) -> Scaler:
    """Calculate training-sample means and population standard deviations for the seven non-light variables."""
    if mask is None:
        use = frame
    else:
        use = frame.loc[np.asarray(mask, dtype=bool)]
    means = {term: float(use[term].mean()) for term in STANDARDIZED_TERMS}
    stds = {term: float(use[term].std(ddof=0)) for term in STANDARDIZED_TERMS}
    for term, sd in list(stds.items()):
        if not np.isfinite(sd) or sd == 0:
            stds[term] = 1.0
    return Scaler(means=means, stds=stds, scope=scope, ddof=0)


def _factorize_sorted(values: Iterable[object]) -> tuple[np.ndarray, list[str]]:
    text = pd.Series(values, dtype="string").astype(str)
    labels = sorted(text.unique().tolist())
    lookup = {label: i for i, label in enumerate(labels)}
    return text.map(lookup).to_numpy(dtype=int), labels


class ExactObjective:
    """Evaluate the nonsmooth allocation objective.

    The district error term is the mean absolute share error; the reported L1
    distance is its sum. The optional NTL anchoring term is the mean absolute
    weight difference. The ridge penalty excludes the unstandardized log-NTL
    coefficient. The study configuration sets the anchoring penalty to zero."""

    def __init__(
        self,
        frame: pd.DataFrame,
        *,
        terms: Sequence[str] = ALL_TERMS,
        train_mask: np.ndarray | pd.Series | None = None,
        scaler: Scaler | None = None,
        lambda_n: float = LAMBDA_N,
        lambda_r: float = LAMBDA_R,
        target_col: str = "energy_share_16district",
        strict_subset: bool = False,
    ) -> None:
        self.frame = frame.reset_index(drop=True).copy()
        self.terms = list(terms)
        self.lambda_n = float(lambda_n)
        self.lambda_r = float(lambda_r)
        self.target_col = target_col
        self.mask = np.ones(len(self.frame), dtype=bool) if train_mask is None else np.asarray(train_mask, dtype=bool)
        if self.mask.size != len(self.frame):
            raise ValueError("train_mask has an incompatible length")
        self.strict_subset = bool(strict_subset)
        self.scaler = scaler or make_scaler(self.frame, None, scope="full_sample")

        if strict_subset:
            self.work = self.frame.loc[self.mask].reset_index(drop=True)
            self.work_mask = np.ones(len(self.work), dtype=bool)
            self.X = self.scaler.transform(self.work, self.terms)
            self.year_code, self.year_labels = _factorize_sorted(self.work["year"])
            district_key = self.work["year"].astype(str) + "|" + self.work["district_name"].astype(str)
            self.district_code, self.district_labels = _factorize_sorted(district_key)
            target = self.work.groupby(["year", "district_name"], sort=True)[target_col].first()
            if self.work["district_name"].nunique() < self.frame["district_name"].nunique():
                target = target / target.groupby(level=0).transform("sum")
            target_lookup = {f"{y}|{d}": float(v) for (y, d), v in target.items()}
            self.target = np.array([target_lookup[label] for label in self.district_labels], dtype=float)
            ntl = self.work["w_ntl_m0"].to_numpy(dtype=float)
            self.ntl = np.empty_like(ntl)
            for code in np.unique(self.year_code):
                idx = self.year_code == code
                s = ntl[idx].sum()
                self.ntl[idx] = ntl[idx] / s if s > 0 else 1.0 / idx.sum()
        else:
            self.work = self.frame
            self.work_mask = self.mask
            self.X = self.scaler.transform(self.work, self.terms)
            self.year_code, self.year_labels = _factorize_sorted(self.work["year"])
            district_key = self.work["year"].astype(str) + "|" + self.work["district_name"].astype(str)
            self.district_code, self.district_labels = _factorize_sorted(district_key)
            target_frame = self.work.loc[self.mask, ["year", "district_name", target_col]].drop_duplicates()
            target_lookup = {
                f"{row.year}|{row.district_name}": float(getattr(row, target_col))
                for row in target_frame.itertuples(index=False)
            }
            self.target_indices = np.array([i for i, label in enumerate(self.district_labels) if label in target_lookup], dtype=int)
            self.target = np.array([target_lookup[self.district_labels[i]] for i in self.target_indices], dtype=float)
            self.ntl = self.work["w_ntl_m0"].to_numpy(dtype=float)

    def weights(self, beta: Sequence[float]) -> np.ndarray:
        beta = np.asarray(beta, dtype=float)
        score = self.X @ beta
        raw = np.exp(np.clip(score, -30.0, 30.0))
        totals = np.bincount(self.year_code, weights=raw, minlength=len(self.year_labels))
        return raw / totals[self.year_code]

    def objective_parts(self, beta: Sequence[float]) -> dict[str, float]:
        beta = np.asarray(beta, dtype=float)
        w = self.weights(beta)
        pred_all = np.bincount(self.district_code, weights=w, minlength=len(self.district_labels))
        if self.strict_subset:
            pred = pred_all
            ntl_diff = np.abs(w - self.ntl)
        else:
            pred = pred_all[self.target_indices]
            ntl_diff = np.abs(w[self.mask] - self.ntl[self.mask])
        district_mae = float(np.mean(np.abs(pred - self.target)))
        ntl_mae = float(np.mean(ntl_diff))
        theta = np.array([beta[i] for i, term in enumerate(self.terms) if term != "log_ntl"], dtype=float)
        ridge = float(np.dot(theta, theta))
        total = district_mae + self.lambda_n * ntl_mae + self.lambda_r * ridge
        return {
            "exact_objective": float(total),
            "district_mae_component": district_mae,
            "ntl_anchor_mae_component": ntl_mae,
            "ridge_squared_norm": ridge,
            "lambda_n": self.lambda_n,
            "lambda_r": self.lambda_r,
        }

    def __call__(self, beta: Sequence[float]) -> float:
        return self.objective_parts(beta)["exact_objective"]


def run_optimizer(
    objective: ExactObjective,
    start: Sequence[float],
    method: str,
    *,
    maxiter: int = 2000,
) -> object:
    start = np.asarray(start, dtype=float)
    if method == "L-BFGS-B":
        options = {"maxiter": maxiter, "ftol": 1e-13, "maxls": 50}
    elif method == "Powell":
        options = {"maxiter": maxiter, "xtol": 1e-10, "ftol": 1e-12}
    elif method == "Nelder-Mead":
        options = {"maxiter": maxiter * 5, "xatol": 1e-9, "fatol": 1e-11, "adaptive": True}
    else:
        raise ValueError(method)
    return minimize(objective, start, method=method, options=options)


def predict_all_models(frame: pd.DataFrame, beta: Sequence[float], scaler: Scaler) -> pd.DataFrame:
    out = frame.sort_values(["year", "street_id"], kind="mergesort").reset_index(drop=True).copy()
    obj = ExactObjective(out, scaler=scaler)
    w2 = obj.weights(beta)
    out["w_m0"] = out["ntl_sum"].clip(lower=0)
    out["w_m0"] = out["w_m0"] / out.groupby("year")["w_m0"].transform("sum")
    within = out["w_m0"] / out.groupby(["year", "district_name"])["w_m0"].transform("sum")
    out["w_m1"] = within * out["energy_share_16district"]
    out["w_m2"] = w2
    s2 = pd.Series(w2).groupby([out["year"], out["district_name"]]).transform("sum").to_numpy()
    out["w_m3"] = w2 * out["energy_share_16district"].to_numpy(dtype=float) / s2
    out["w_m4"] = w2 * out["elec_share_16district"].to_numpy(dtype=float) / s2
    for model in ["m0", "m1", "m2", "m3", "m4"]:
        out[f"allocation_{model}"] = out[f"w_{model}"] * out["city_total"]
    out["district_id"] = out["district_code"].astype(str)
    return out
