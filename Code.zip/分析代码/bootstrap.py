"""Subdistrict block bootstrap using the 1,000 recorded draw lists.

We retain all seven annual records for each draw. Repeated subdistricts enter
standardization, normalization, and district aggregation as separate blocks.
Each fitted model is applied to the original 343 subdistricts using its resample
scaler and the original district shares. The main frequencies use all 1,000
fits; converged-only summaries use their own denominators."""
from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .core import ALL_TERMS, ExactObjective, make_scaler, predict_all_models
from .estimation import append_jsonl, endpoint_details, require_new_output, save_csv, save_json
from .validation import ordered_panel


def rank_descending(values, street_ids):
    """Rank shares in descending order, breaking ties by ascending string-valued subdistrict ID."""
    order = np.lexsort((np.asarray(street_ids, dtype=str), -np.asarray(values)))
    ranks = np.empty(len(order), dtype=np.uint16)
    ranks[order] = np.arange(1, len(order) + 1, dtype=np.uint16)
    return ranks


def prediction(features, beta, means, stds, year_code, district_year_code, energy_share, electricity_share):
    matrix = features.copy()
    matrix[:, 1:] = (matrix[:, 1:] - means) / stds
    raw = np.exp(np.clip(matrix @ beta, -30.0, 30.0))
    annual_total = np.bincount(year_code, weights=raw)
    m3 = raw / annual_total[year_code]
    district_total = np.bincount(district_year_code, weights=m3)
    m4 = m3 * energy_share / district_total[district_year_code]
    m4prime = m3 * electricity_share / district_total[district_year_code]
    result = np.column_stack((m3, m4, m4prime))
    if not np.isfinite(result).all():
        raise ValueError("Bootstrap predictions contain non-finite values")
    return result


def reconstruct_sample(panel, draw, replicate):
    """Reconstruct the sample in draw order, preserving repeated subdistrict blocks."""
    sample_ids = np.asarray(draw["street_ids"], dtype=np.int64)
    if len(sample_ids) != 343:
        raise ValueError("Each draw must contain 343 subdistrict blocks")
    if int(draw["replicate"]) != replicate:
        raise ValueError("Draw order differs from the saved list")
    sample_hash = hashlib.sha256(sample_ids.tobytes()).hexdigest()
    index = panel.set_index("street_id", drop=False)
    boot = index.loc[sample_ids.astype(str)].reset_index(drop=True).copy()
    boot["bootstrap_cluster"] = np.repeat(np.arange(343), 7)
    boot["street_id"] = boot.street_id.astype(str) + "__draw" + boot.bootstrap_cluster.astype(str).str.zfill(3)
    if len(boot) != 2401 or boot.groupby("bootstrap_cluster").year.nunique().ne(7).any():
        raise ValueError("The resample does not retain seven annual records per subdistrict block")
    return boot, sample_hash


def run_bootstrap(frame, cfg, beta, draws, outdir):
    panel = ordered_panel(frame, cfg)
    settings = cfg["bootstrap"]
    if len(draws) != settings["draws"] or settings["draws"] != 1000:
        raise ValueError("The study configuration requires the 1,000 recorded draw lists")
    dest = require_new_output(Path(outdir) / "bootstrap")
    beta = np.asarray(beta, dtype=float)
    features = panel[ALL_TERMS].to_numpy()
    year_code = pd.factorize(panel.year, sort=True)[0]
    district_code = pd.factorize(panel.year.astype(str) + "|" + panel.district_name, sort=True)[0]
    ids = np.sort(panel.street_id.unique()).astype(str)
    years = sorted(panel.year.unique())
    energy = panel.energy_share_16district.to_numpy()
    electricity = panel.elec_share_16district.to_numpy()
    scopes = ["initial_all", "initial_success", "continued_all", "continued_success"]
    ks = [18, 35, 69]
    counts = {scope: np.zeros((7, 2, 3, 343), dtype=int) for scope in scopes}
    denominators = {scope: 0 for scope in scopes}
    initial, continued = [], []
    for replicate, draw in enumerate(draws, 1):
        sample, sample_hash = reconstruct_sample(panel, draw, replicate)
        scaler = make_scaler(sample, scope=f"bootstrap_{replicate}_sample")
        objective = ExactObjective(sample, scaler=scaler, lambda_n=cfg["lambda_N"], lambda_r=cfg["lambda_R"])
        fit = minimize(objective, beta, method="L-BFGS-B", options=settings["initial_options"])
        row = endpoint_details(
            fit, objective, beta, replicate=replicate, sample_sha256=sample_hash,
            scaler_means=scaler.means, scaler_stds=scaler.stds,
        )
        initial.append(row)
        append_jsonl(row, dest / "initial_endpoints.jsonl")
        final = fit
        if not fit.success:
            final = minimize(objective, fit.x, method="L-BFGS-B", options=settings["continuation_options"])
            if objective(final.x) > objective(fit.x) + 1e-10:
                raise AssertionError("The objective increased after optimization continued")
            append_jsonl(
                endpoint_details(final, objective, fit.x, replicate=replicate, sample_sha256=sample_hash),
                dest / "continuation_endpoints.jsonl",
            )
        continued.append(endpoint_details(final, objective, fit.x, replicate=replicate, sample_sha256=sample_hash))
        means = np.asarray([scaler.means[term] for term in ALL_TERMS[1:]])
        stds = np.asarray([scaler.stds[term] for term in ALL_TERMS[1:]])
        for base, endpoint in [("initial", fit), ("continued", final)]:
            predicted = prediction(features, endpoint.x, means, stds, year_code, district_code, energy, electricity)
            weights = predicted[:, 1:].reshape(7, 343, 2).transpose(0, 2, 1)
            if np.max(np.abs(weights.sum(axis=2) - 1)) >= 1e-11:
                raise AssertionError("Annual bootstrap prediction shares do not sum to one")
            for scope in [base + "_all"] + ([base + "_success"] if endpoint.success else []):
                denominators[scope] += 1
                for yi in range(7):
                    for mi in range(2):
                        ranks = rank_descending(weights[yi, mi], ids)
                        for ki, k in enumerate(ks):
                            counts[scope][yi, mi, ki] += ranks <= k
        if replicate % 50 == 0:
            print("Bootstrap", replicate, "initial_success", denominators["initial_success"], "continued_success", denominators["continued_success"], flush=True)
    save_csv(pd.DataFrame(initial), dest / "initial_endpoints.csv")
    save_csv(pd.DataFrame(continued), dest / "continued_endpoints.csv")
    canonical = predict_all_models(panel, beta, make_scaler(panel, scope="full_sample"))
    metadata = canonical[canonical.year.eq(2022)].set_index("street_id").loc[ids]
    rows = []
    for scope in scopes:
        denominator = denominators[scope]
        for yi, year in enumerate(years):
            annual = canonical[canonical.year.eq(year)].set_index("street_id").loc[ids]
            for mi, model in enumerate(["M4", "M4prime"]):
                baseline_rank = rank_descending(annual["w_m3" if mi == 0 else "w_m4"].to_numpy(), ids)
                for ki, k in enumerate(ks):
                    if counts[scope][yi, mi, ki].sum() != denominator * k:
                        raise AssertionError("Selection counts do not equal the number of draws times the shortlist size")
                for j, sid in enumerate(ids):
                    row = {
                        "scope": scope, "year": int(year), "model": model, "street_id": sid,
                        "street_name": metadata.loc[sid, "street_name"], "district_name": metadata.loc[sid, "district_name"],
                        "baseline_rank": int(baseline_rank[j]), "denominator": denominator,
                    }
                    for ki, k in enumerate(ks):
                        row[f"top{k}_frequency"] = counts[scope][yi, mi, ki, j] / denominator if denominator else np.nan
                        row[f"top{k}_count"] = int(counts[scope][yi, mi, ki, j])
                    rows.append(row)
    frequencies = pd.DataFrame(rows)
    save_csv(frequencies, dest / "frequencies.csv")
    save_csv(frequencies.query('year == 2022 and model == "M4" and baseline_rank <= 35'), dest / "baseline_top35_2022.csv")
    summary = {
        "reps": len(draws), "denominators": denominators, "frequency_counts_conserved": True,
        "main_scope": "continued_all", "rank_ties": "share descending, street_id string ascending",
        "draws": "Fixed supplied draw list; duplicate streets remain separate seven-year blocks",
        "prediction": "Original 343 streets with each draw's scaler and original district shares",
    }
    save_json(summary, dest / "summary.json")
    return summary
