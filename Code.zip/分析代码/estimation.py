"""Optimization and output functions shared by holdout and bootstrap analyses."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .core import ExactObjective


def require_new_output(path: Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=False)
    return path


def save_csv(frame: pd.DataFrame, path: Path) -> None:
    # Convert nested optimizer results to JSON-compatible values.
    out = frame.copy()
    for name in out.columns:
        if out[name].map(lambda x: isinstance(x, (list, dict))).any():
            out[name] = out[name].map(
                lambda x: json.dumps(x, ensure_ascii=False) if isinstance(x, (list, dict)) else x
            )
    out.to_csv(path, index=False, encoding="utf-8-sig", float_format="%.17g")


def save_json(value: object, path: Path) -> None:
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def append_jsonl(row: dict, path: Path) -> None:
    with Path(path).open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, ensure_ascii=False) + "\n")


def endpoint_details(fit, objective, start, method="L-BFGS-B", **extra) -> dict:
    jac = getattr(fit, "jac", None)
    if not np.isfinite(fit.x).all() or not np.isfinite(objective(fit.x)):
        raise ValueError("The optimization endpoint contains non-finite values")
    return {
        **extra,
        "optimizer": method,
        "start_vector": np.asarray(start, dtype=float).tolist(),
        "end_vector": np.asarray(fit.x, dtype=float).tolist(),
        "success": bool(fit.success),
        "message": str(fit.message),
        "iterations": int(getattr(fit, "nit", -1)),
        "function_evaluations": int(getattr(fit, "nfev", -1)),
        "gradient_norm": float(np.linalg.norm(jac)) if jac is not None else None,
        **objective.objective_parts(fit.x),
    }


def fit_candidates(frame, cfg, terms, scaler, mask, parent, options, label, logfile):
    """Fit zero and NTL1 starts; include the parent start in the initialization-sensitivity comparison."""
    objective = ExactObjective(
        frame, terms=terms, scaler=scaler, train_mask=mask,
        lambda_n=cfg["lambda_N"], lambda_r=cfg["lambda_R"],
    )
    rows = []
    starts = [
        ("parent", np.asarray(parent, dtype=float)),
        ("zero", np.zeros(len(terms))),
        ("NTL1", np.r_[1.0, np.zeros(len(terms) - 1)]),
    ]
    for name, start in starts:
        fit = minimize(objective, start, method="L-BFGS-B", options=options)
        row = endpoint_details(
            fit, objective, start, label=label, initialization=name,
            terms=list(terms), scaler_means=scaler.means, scaler_stds=scaler.stds,
        )
        rows.append(row)
        append_jsonl(row, logfile)
    return min(rows[1:], key=lambda r: r["exact_objective"]), min(rows, key=lambda r: r["exact_objective"]), rows
