"""Shortlist comparisons and electricity-and-heat reallocation.

We use the all-sector EDGAR and ODIAC distributions as alternative spatial
weights. Full reallocation fixes the citywide total; the upper-bound
calculation also fixes district totals."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from .core import ALL_TERMS, ExactObjective, Scaler, rank_corr, linear_corr, top_ids


def save_csv(frame, path):
    frame.to_csv(path, index=False, encoding='utf-8-sig', float_format='%.17g')


def ranked(values, identifiers):
    order = np.lexsort((np.asarray(identifiers).astype(str), -np.asarray(values)))
    ranks = np.empty(len(order), dtype=int)
    ranks[order] = np.arange(1, len(order) + 1)
    return ranks


def internal_comparisons(panel):
    comparisons, concentration, adjacent = [], [], []
    for year, group in panel.groupby('year', sort=True):
        for model, column in [('M2', 'w_m1'), ('M4prime', 'w_m4')]:
            for k in (18, 35, 69):
                common = len(top_ids(group, 'w_m3', k) & top_ids(group, column, k))
                comparisons.append(dict(year=int(year), comparison=model, k=k,
                    spearman=rank_corr(group.w_m3, group[column]),
                    common_n=common, overlap_rate=common / k))
        for model, column in [('M4', 'w_m3'), ('M4prime', 'w_m4')]:
            selected = top_ids(group, column, 35)
            concentration.append(dict(year=int(year), model=model,
                top35_concentration=float(group.loc[group.street_id.astype(str).isin(selected), column].sum())))
    for year in range(2016, 2022):
        a = panel[panel.year.eq(year)].sort_values('street_id')
        b = panel[panel.year.eq(year + 1)].sort_values('street_id')
        for k in (18, 35, 69):
            common = len(top_ids(a, 'w_m3', k) & top_ids(b, 'w_m3', k))
            adjacent.append(dict(year1=year, year2=year + 1, k=k,
                spearman=rank_corr(a.w_m3, b.w_m3), common_n=common, overlap_rate=common / k))
    return pd.DataFrame(comparisons), pd.DataFrame(concentration), pd.DataFrame(adjacent)


def external_comparison(panel, product, value_column, label):
    keys = ['year', 'street_id']
    if product.duplicated(keys).any():
        raise ValueError(f'{label}: duplicate year-subdistrict keys')
    rows = []
    merged = panel.merge(product[keys + [value_column]], on=keys, how='inner', validate='one_to_one')
    if len(merged) != len(product) or not len(merged):
        raise ValueError(f'{label}: product year-subdistrict keys differ from the panel')
    for year, group in merged.groupby('year', sort=True):
        if len(group) != 343:
            raise ValueError(f'{label}：{year} does not contain all 343 subdistricts')
        values = group[value_column].to_numpy(dtype=float)
        if not np.isfinite(values).all() or np.min(values) < 0 or values.sum() <= 0:
            raise ValueError(f'{label}: emissions contain non-finite or negative values, or their sum is not positive')
        group = group.assign(external_share=values / values.sum())
        for k in (18, 35, 69):
            common = len(top_ids(group, 'w_m3', k) & top_ids(group, 'external_share', k))
            rows.append(dict(year=int(year), comparison=label, k=k,
                spearman=rank_corr(group.w_m3, group.external_share),
                common_n=common, overlap_rate=common / k))
    return pd.DataFrame(rows)


def thermal_scenarios(panel, sectors, products):
    """Calculate full-reallocation scenarios and district-constrained upper bounds.

    sectors contains year, city_scope1_mt, and power_heat_scope1_mt.
    products maps each product name to a table of year, street_id, and emissions."""
    if sectors.year.duplicated().any():
        raise ValueError('Duplicate years in the sector data')
    sectors = sectors.set_index('year')
    metrics, caps, selected, budgets = [], [], [], []
    for label, product in products.items():
        if product.duplicated(['year', 'street_id']).any():
            raise ValueError(f'{label}: duplicate year-subdistrict keys')
        for year, source in product.groupby('year', sort=True):
            group = panel[panel.year.eq(year)].sort_values('street_id').reset_index(drop=True)
            q = source.set_index('street_id').reindex(group.street_id).emissions.to_numpy(dtype=float)
            if len(source) != 343 or not np.isfinite(q).all() or (q < 0).any() or q.sum() <= 0:
                raise ValueError(f'{label}: invalid spatial-template values or incomplete subdistrict coverage')
            city = float(sectors.loc[year, 'city_scope1_mt'])
            heat = float(sectors.loc[year, 'power_heat_scope1_mt'])
            if not np.isfinite([city, heat]).all() or not 0 < heat <= city:
                raise ValueError('CEADs totals must be finite, with 0 < electricity-and-heat total <= citywide total')
            if not np.allclose(group.city_total, city * 100, atol=1e-8, rtol=0):
                raise ValueError('Citywide totals differ from the panel (Mt CO2 x 100 = 10,000 tonnes CO2)')
            p, q = heat / city, q / q.sum()
            w = group.w_m3.to_numpy()
            codes, names = pd.factorize(group.district_name, sort=True)
            s, qd = np.bincount(codes, weights=w), np.bincount(codes, weights=q)
            ratios = np.divide(s, p * qd, out=np.full_like(s, np.inf), where=qd > 0)
            limiting = int(np.argmin(ratios))
            cap = min(float(ratios[limiting]), 1.0)
            caps.append(dict(year=int(year), template=label,
                lambda_max_preserving_district=cap, limiting_district_name=str(names[limiting])))
            grid = sorted(set(np.round(np.arange(0, 1.0001, .05), 2).tolist() + [cap]))
            for amount in grid:
                remaining = s - amount * p * qd
                for rule in ('city_total_only', 'preserve_district'):
                    feasible = rule == 'city_total_only' or np.min(remaining) >= -1e-12
                    row = dict(year=int(year), template=label, constraint=rule, feasible=bool(feasible))
                    row['lambda'] = amount
                    if feasible:
                        values = ((1 - amount * p) * w + amount * p * q if rule == 'city_total_only'
                                  else w / s[codes] * remaining[codes] + amount * p * q)
                        assert np.min(values) >= -1e-12 and abs(values.sum() - 1) < 1e-12
                        error = float(np.max(abs(np.bincount(codes, weights=values) - s)))
                        if rule == 'preserve_district':
                            assert error < 1e-12
                        comparison = group.assign(scenario=values)
                        row.update(spearman_vs_M4=rank_corr(w, values),
                            top35_common=len(top_ids(comparison, 'w_m3', 35) & top_ids(comparison, 'scenario', 35)),
                            max_district_deviation=error)
                        if year == 2022 and amount == 1 and rule == 'city_total_only':
                            short = group[['year', 'street_id', 'street_name', 'district_name']].copy()
                            short['template'] = label
                            short['scenario_share'], short['baseline_share'] = values, w
                            short['scenario_rank'] = ranked(values, group.street_id)
                            selected.append(short)
                    metrics.append(row)
            # Keep negative residuals to identify where the template exceeds district totals.
            budget_grid = sorted(set(np.round(np.arange(0, 1.00001, .01), 2).tolist() + [cap]))
            for amount in budget_grid:
                for j, name in enumerate(names):
                    budgets.append({'year': int(year), 'template': label, 'district_name': str(name),
                        'lambda': float(amount), 'original_target_tCO2': float(s[j] * city * 1e6),
                        'assigned_sector_at_lambda1_tCO2': float(qd[j] * heat * 1e6),
                        'remaining_budget_tCO2': float((s[j] - amount * p * qd[j]) * city * 1e6)})
    return (pd.DataFrame(metrics), pd.DataFrame(caps),
            pd.concat(selected, ignore_index=True) if selected else pd.DataFrame(), pd.DataFrame(budgets))


def building_comparisons(panel, cbra, beta, scaler):
    """Compare building inputs with the model coefficients and standardization parameters held fixed."""
    if cbra.duplicated(['year', 'street_id']).any():
        raise ValueError('Duplicate year-subdistrict keys in the CBRA data')
    base = cbra[cbra.year.eq(2021)].set_index('street_id').roof_density
    dynamic = cbra.set_index(['year', 'street_id']).roof_density
    out, rows = panel.copy(), []
    for label, values in [('fixed2021', out.street_id.map(base)),
                          ('dynamic', [dynamic.loc[(min(int(y), 2021), int(s))]
                                       for y, s in zip(out.year, out.street_id)])]:
        values = np.asarray(values, dtype=float)
        if not np.isfinite(values).all() or (values < 0).any():
            raise ValueError('CBRA densities contain missing, non-finite, or negative values')
        temp = panel.copy()
        temp['w_ntl_m0'] = temp.w_m0
        temp['log_building_density'] = np.log1p(1000 * values)
        weights = ExactObjective(temp, scaler=scaler).weights(beta)
        totals = pd.Series(weights).groupby([temp.year, temp.district_name]).transform('sum').to_numpy()
        out[label + '_pre'] = weights
        out[label + '_closed'] = weights / totals * temp.energy_share_16district.to_numpy()
    for year, group in out.groupby('year', sort=True):
        for phase, original in [('pre', 'w_m2'), ('closed', 'w_m3')]:
            for comparison, a, b in [('temporal', 'dynamic_' + phase, 'fixed2021_' + phase),
                                     ('source', 'fixed2021_' + phase, original)]:
                rows.append(dict(year=int(year), phase=phase, comparison=comparison,
                    spearman=rank_corr(group[a], group[b]),
                    top35_common=len(top_ids(group, a, 35) & top_ids(group, b, 35))))
    return pd.DataFrame(rows), out


def candidates(panel, frequencies, scenarios=None):
    """Classify selection frequencies and identify core candidates using M4-prime and both electricity-and-heat scenarios."""
    group = panel[panel.year.eq(2022)].sort_values('street_id').reset_index(drop=True).copy()
    freq = frequencies[(frequencies.year == 2022) & (frequencies.model == 'M4')
                       & (frequencies.scope == 'continued_all')].set_index('street_id')
    if len(freq) != 343 or not freq.index.is_unique or set(freq.index) != set(group.street_id):
        raise ValueError('Final all-run selection frequencies are required for all 343 subdistricts')
    values = freq.top35_frequency.to_numpy(dtype=float)
    if not np.isfinite(values).all() or ((values < 0) | (values > 1)).any():
        raise ValueError('Selection frequencies must be finite and between zero and one')
    if not freq.denominator.eq(1000).all():
        raise ValueError('Selection frequencies use all 1,000 runs as the denominator')
    if not np.allclose(values * 1000, freq.top35_count, atol=1e-10, rtol=0):
        raise ValueError('Selection frequencies differ from selection counts divided by the denominator')
    if not np.allclose(freq.top35_count, np.round(freq.top35_count), atol=1e-10, rtol=0) or freq.top35_count.sum() != 35000:
        raise ValueError('Invalid selection counts for 1,000 top-35 lists')
    for name, column in [('M4', 'w_m3'), ('M4prime', 'w_m4'), ('M2', 'w_m1')]:
        group[name + '_rank'] = ranked(group[column], group.street_id)
    if not np.array_equal(group.street_id.map(freq.baseline_rank), group.M4_rank):
        raise ValueError('Bootstrap baseline ranks differ from ranks calculated with the supplied parameters')
    group['bootstrap_frequency'] = group.street_id.map(freq.top35_frequency)
    group['frequency_layer'] = np.select([group.bootstrap_frequency.ge(.8), group.bootstrap_frequency.ge(.5)],
                                        ['High-frequency', 'Secondary'], default='Sample-sensitive')
    columns = ['street_id', 'street_name', 'district_name', 'M4_rank', 'M4prime_rank',
               'M2_rank', 'bootstrap_frequency', 'frequency_layer']
    if scenarios is not None:
        if not scenarios.year.eq(2022).all():
            raise ValueError('Core candidates require the 2022 scenarios')
        if set(scenarios.template.unique()) != {'EDGAR', 'ODIAC'}:
            raise ValueError('Core-candidate classification requires both EDGAR and ODIAC scenarios')
        for label in ('EDGAR', 'ODIAC'):
            part = scenarios[scenarios.template.eq(label)].set_index('street_id')
            if len(part) != 343 or not part.index.is_unique or set(part.index) != set(group.street_id):
                raise ValueError('Scenario subdistrict coverage is incomplete or contains duplicate keys')
            if set(part.scenario_rank) != set(range(1, 344)):
                raise ValueError('Scenario ranks must contain each integer from 1 to 343 once')
            if 'baseline_share' in part and not np.allclose(group.street_id.map(part.baseline_share), group.w_m3, atol=1e-14, rtol=0):
                raise ValueError('Scenario baseline shares differ from shares calculated with the supplied parameters')
            group[label + '_selected'] = group.street_id.map(part.scenario_rank.le(35))
            columns.append(label + '_selected')
        group['core_candidate'] = (group.M4_rank.le(35) & group.bootstrap_frequency.ge(.8)
                                  & group.M4prime_rank.le(35) & group.EDGAR_selected & group.ODIAC_selected)
        columns.append('core_candidate')
    return group[group.M4_rank.le(35)][columns].sort_values('M4_rank')


def run_summary(panel, beta, scaler, outdir, external=None):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    comparison, concentration, adjacent = internal_comparisons(panel)
    save_csv(concentration, outdir / 'concentration.csv')
    save_csv(adjacent, outdir / 'adjacent_years.csv')
    completed = ['internal comparisons', 'concentration', 'adjacent-year stability']
    if external is not None:
        external = Path(external)
        products = {}
        for label, filename, value in [('EDGAR', 'edgar.csv', 'edgar_co2_ton'),
                                       ('ODIAC', 'odiac.csv', 'odiac_annual_tCO2')]:
            path = external / filename
            if path.exists():
                product = pd.read_csv(path, float_precision='round_trip')
                if label == 'ODIAC' and 'year' not in product:
                    product = product.assign(year=2022)
                comparison = pd.concat([comparison, external_comparison(panel, product, value, label)], ignore_index=True)
                products[label] = product[['year', 'street_id', value]].rename(columns={value: 'emissions'})
                completed.append(label + ' comparison')
        if (external / 'sectors.csv').exists() and products:
            sectors = pd.read_csv(external / 'sectors.csv', float_precision='round_trip')
            outputs = thermal_scenarios(panel, sectors, products)
            for frame, name in zip(outputs, ['thermal_metrics.csv', 'thermal_caps.csv', 'thermal_shortlists_2022.csv', 'district_budgets.csv']):
                save_csv(frame, outdir / name)
            completed.append('thermal scenarios for supplied products')
        if (external / 'cbra.csv').exists():
            result, values = building_comparisons(panel, pd.read_csv(external / 'cbra.csv', float_precision='round_trip'), beta, scaler)
            save_csv(result, outdir / 'building_comparisons.csv')
            save_csv(values, outdir / 'building_scenario_weights.csv')
            completed.append('fixed-parameter building comparisons')
    save_csv(comparison, outdir / 'shortlist_comparisons.csv')
    (outdir / 'completed.json').write_text(json.dumps({'completed': completed, 'model_refits': 0}, ensure_ascii=False, indent=2) + '\n')
