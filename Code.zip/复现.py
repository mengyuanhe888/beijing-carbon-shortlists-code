"""Calculate subdistrict emission allocations, compare shortlists, and estimate the study models."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_package():
    manifest = ROOT / 'manifest.json'
    entries = json.loads(manifest.read_text(encoding='utf-8'))
    for relative, expected in entries.items():
        path = ROOT / relative
        if not path.is_file() or digest(path) != expected:
            raise ValueError(f'Missing file or checksum mismatch: {relative}')
    for path in ROOT.rglob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    from 分析代码.model import load_panel, load_config, replay
    frame = load_panel(ROOT / '模型数据/panel.csv')
    config = load_config(ROOT / '参数配置/method.json')
    predicted = replay(frame, config)
    for index in range(5):
        assert (predicted.groupby('year')[f'w_m{index}'].sum() - 1).abs().max() < 1e-11
    print(f'Package check passed: {len(entries)} files; {len(frame)} subdistrict-year records. Predictions checked using saved coefficients; no model fitting.')


def output_location(path):
    output = path.expanduser().resolve()
    if output.is_relative_to(ROOT) or ROOT.is_relative_to(output):
        raise ValueError('The output directory must be outside the extracted package.')
    if output.exists():
        raise FileExistsError(f'Output directory already exists: {output}')
    return output


def write_provenance(output, args):
    inputs = {'panel': digest(args.panel), 'method_config': digest(args.config)}
    for name in ('parameters', 'draws', 'frequencies', 'scenarios'):
        path = getattr(args, name, None)
        if path is not None:
            inputs[name] = digest(path)
    external = getattr(args, 'external', None)
    if external is not None:
        for name in ('edgar.csv', 'odiac.csv', 'sectors.csv', 'cbra.csv'):
            path = external / name
            if path.is_file():
                inputs['external/' + name] = digest(path)
    source = {str(p.relative_to(ROOT)): digest(p) for p in (ROOT / '分析代码').glob('*.py')}
    source['复现.py'] = digest(Path(__file__))
    record = {'command': args.command, 'input_sha256': inputs, 'code_sha256': source,
              'parameter_source': 'supplied parameters file' if args.parameters else 'saved manuscript parameters'}
    if args.command == 'validate':
        record['validation_part'] = args.part
    if args.command == 'fit':
        record['parameter_source'] = 'new full-sample fit'
    (output / 'run.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')


def main():
    # Accept --check as an alias for the check subcommand.
    argv = sys.argv[1:]
    if argv == ['--check']:
        argv = ['check']
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('check', help='Check files, panel inputs, and saved-coefficient predictions')
    commands = {
        'predict': 'Calculate weights and emissions for all five allocation schemes using saved coefficients',
        'fit': 'Estimate the full-sample model from 20 starts and three optimizers',
        'validate': 'Run holdout or variable-configuration analyses',
        'bootstrap': 'Refit the 1,000 recorded samples and calculate selection frequencies',
        'compare': 'Compare shortlists, external products, and electricity-and-heat scenarios',
        'shortlist': 'Summarize selection frequencies and identify core candidates from scenario ranks',
    }
    for name, help_text in commands.items():
        cmd = sub.add_parser(name, help=help_text)
        cmd.add_argument('--panel', type=Path, default=ROOT / '模型数据/panel.csv')
        cmd.add_argument('--config', type=Path, default=ROOT / '参数配置/method.json')
        cmd.add_argument('--parameters', type=Path, help='parameters.json from a previous run; defaults to the saved study coefficients')
        cmd.add_argument('--out', type=Path, required=True, help='New output directory outside the extracted package')
        if name == 'validate':
            cmd.add_argument('--part', choices=['all', 'holdout', 'blocks', 'joint'], default='all')
        if name == 'bootstrap':
            cmd.add_argument('--draws', type=Path, default=ROOT / '参数配置/bootstrap_draws.json')
        if name == 'compare':
            cmd.add_argument('--external', type=Path, help='Directory containing comparison CSV files described in README.md')
        if name == 'shortlist':
            cmd.add_argument('--frequencies', type=Path, required=True)
            cmd.add_argument('--scenarios', type=Path, help='thermal_shortlists_2022.csv; required for core-candidate classification')
    args = parser.parse_args(argv)
    if args.command == 'check':
        check_package()
        return
    from dataclasses import asdict
    import numpy as np
    import pandas as pd
    from 分析代码 import model
    from 分析代码.core import predict_all_models
    from 分析代码.summaries import save_csv, run_summary, candidates
    out = output_location(args.out)
    frame, config = model.load_panel(args.panel), model.load_config(args.config)
    beta, scaler = model.load_parameters(args.parameters) if args.parameters else model.saved_parameters(config)
    if args.command == 'fit':
        if args.parameters is not None:
            parser.error('fit uses the 20 configured starts and does not accept --parameters.')
        model.fit(frame, config, out)
    elif args.command == 'predict':
        out.mkdir(parents=True)
        predicted = predict_all_models(frame, beta, scaler)
        save_csv(predicted, out / 'model_panel.csv')
        params = {'beta': np.asarray(beta).tolist(), 'scaler': asdict(scaler),
                  'source': 'supplied_parameters' if args.parameters else 'saved_coefficients'}
        (out / 'parameters.json').write_text(json.dumps(params, ensure_ascii=False, indent=2) + '\n')
    elif args.command == 'validate':
        from 分析代码 import validation
        routines = {'all': validation.run_validation, 'holdout': validation.run_holdout,
                    'blocks': validation.run_blocks, 'joint': validation.run_joint}
        routines[args.part](frame, config, beta, out)
    elif args.command == 'bootstrap':
        from 分析代码.bootstrap import run_bootstrap
        draws = json.loads(args.draws.read_text(encoding='utf-8'))
        run_bootstrap(frame, config, beta, draws, out)
    elif args.command == 'compare':
        if args.external is not None:
            args.external = args.external.expanduser().resolve()
            if not args.external.is_dir():
                raise FileNotFoundError(args.external)
            if not any((args.external / x).exists() for x in ('edgar.csv', 'odiac.csv', 'sectors.csv', 'cbra.csv')):
                raise ValueError('No comparison CSV files found; filenames and fields are listed in README.md.')
        run_summary(predict_all_models(frame, beta, scaler), beta, scaler, out, args.external)
    elif args.command == 'shortlist':
        frequencies = pd.read_csv(args.frequencies, float_precision='round_trip')
        scenarios = pd.read_csv(args.scenarios, float_precision='round_trip') if args.scenarios else None
        result = candidates(predict_all_models(frame, beta, scaler), frequencies, scenarios)
        out.mkdir(parents=True)
        save_csv(result, out / 'shortlist_2022.csv')
    write_provenance(out, args)
    print(f'{args.command} complete. Results: {out}')


if __name__ == '__main__':
    main()
