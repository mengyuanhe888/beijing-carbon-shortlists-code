"""Check the code distribution's checksums and Python syntax without study inputs."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def main():
    entries = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    for name, expected in entries.items():
        path = ROOT / name
        if not path.is_file():
            raise FileNotFoundError(f"Missing distributed file: {name}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"Checksum mismatch: {name}")
    scripts = sorted(name for name in entries if name.endswith(".py"))
    for name in scripts:
        ast.parse((ROOT / name).read_text(encoding="utf-8"), filename=name)
    print(f"Code check passed: {len(entries)} files and {len(scripts)} Python scripts.")
    print("No study inputs were read; no models or numerical results were reproduced.")


if __name__ == "__main__":
    main()
