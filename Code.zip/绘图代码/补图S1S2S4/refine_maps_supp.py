"""Physical-millimetre layout corrections; all plotting data remain unchanged."""
from redraw import *
from shapely.geometry import box
import moderate_grouping as m
import redraw as r

def axmm(fig,x,y,w,h):
    fw,fh=fig.get_size_inches()*25.4
    return fig.add_axes([x/fw,y/fh,w/fw,h/fh])

def moveax(fig,ax,x,y,w,h):
    fw,fh=fig.get_size_inches()*25.4
    ax.set_position([x/fw,y/fh,w/fw,h/fh])

def labelmm(fig,x,y,label,**kw):
    fw,fh=fig.get_size_inches()*25.4
    return fig.text(x/fw,y/fh,label,**kw)

def inset_frame(ax):
    ax.axis('on');ax.set_xticks([]);ax.set_yticks([])
    for sp in ax.spines.values():sp.set_visible(True);sp.set_color('#95A1A8');sp.set_linewidth(.5)

def map_inset_checks(fig,axes,insets):
    fig.canvas.draw();union=streets.geometry.union_all();covered=[]
    for main,ins in zip(axes,insets):
        bb=ins.get_window_extent();p=main.transData.inverted().transform([[bb.x0,bb.y0],[bb.x1,bb.y1]])
        covered.append(float(union.intersection(box(p[0,0],p[0,1],p[1,0],p[1,1])).area))
    assert max(covered)==0,covered
    return covered

def main3():
    fig=figmm(190,103);axes=[];insets=[]
    for i,(model,col,sub) in enumerate([('M1','w_m0','Nighttime-light baseline'),('M2','w_m1','District-constrained lights'),('M4','w_m3','Multisource allocation')]):
        x=4.75+62.13*i
        labelmm(fig,x,98.5,f'({"abc"[i]})  {model}',fontsize=9.5,weight='bold',va='top')
        labelmm(fig,x,93.5,sub,fontsize=8,color=MUTED,va='top')
        ax=axmm(fig,x,30,57.4,57.7);sharemap(ax,col);zoom_frame(ax);axes.append(ax)
        ins=axmm(fig,x+42.0,25,15.3,16.8);sharemap(ins,col,zoom);inset_frame(ins);insets.append(ins)
    labelmm(fig,4.75,20,'Insets: central-area detail',fontsize=8,color=MUTED,va='center')
    fmt=lambda x:f'{x:.2f}' if x<1 else f'{x:.1f}'
    colorbar(fig,[24.7/190,12/103,142.5/190,2/103],r.SEQ,Normalize(0,1),positions[1:],[fmt(v) for v in breaks[1:]],'Allocation share of Beijing total (%)')
    covered=map_inset_checks(fig,axes,insets)
    export(fig,'Fig03_spatial_allocation',extra={'panels':3,'palette':'cividis','data_mapping':'unchanged pooled empirical quantiles','insets':'lower right of each main map','inset_overlap_map_area_m2':covered,'same_full_extent_and_scale':True,'same_inset_extent_and_scale':True,'title_top_mm':98.5,'subtitle_top_mm':93.5,'shared_colorbar':True})

def main4():
    fig=figmm(190,108);axes=[];insets=[]
    for x,fn,letter,title,sub in [(8.55,diffmap,'a','Within-district reallocation','Same municipal total and district shares'),(100.7,classmap,'b','Top-35 list membership','Common and specification-specific selections')]:
        labelmm(fig,x,103.5,f'({letter})  {title}',fontsize=9.5,weight='bold',va='top')
        labelmm(fig,x,98.5,sub,fontsize=8,color=MUTED,va='top')
        ax=axmm(fig,x-.95,28,82.65,66.05);out=fn(ax);zoom_frame(ax);axes.append(ax)
        if letter=='a':norm=out
        ins=axmm(fig,x+60.8,21,22.8,20.23);fn(ins,zoom);inset_frame(ins);insets.append(ins)
    colorbar(fig,[10.45/190,12/108,75.05/190,2.14/108],DIV,norm,[-10,-1,0,1,10],['−10','−1','0','1','10'],'ln(M4 share / M2 share)')
    labelmm(fig,8.55,19.0,'Hatching = positive change',fontsize=8,color=MUTED,va='center')
    # Same legend zone and heading baseline as the left colour scale.
    labelmm(fig,100.7,19.0,'Insets use the same central-area extent',fontsize=8,color=MUTED,va='center')
    handles=[Patch(facecolor=c,edgecolor=MUTED,linewidth=.5,label=f'{lab} · {int((classes==k).sum())}') for k,lab,c in [('Both','Both','#354558'),('M2 only','M2 only',SKY),('M4 only','M4 only',ORANGE),('Neither','Neither','#F2F4F5')]]
    # Categorical swatches align exactly with the colour-bar strip, not the
    # padding of a Matplotlib legend frame. The two legends retain separate units.
    for x,y,k,lab,c in [(105.0,13.07,'Both','Both','#354558'),(105.0,7.8,'M2 only','M2 only',SKY),(138.5,13.07,'M4 only','M4 only',ORANGE),(138.5,7.8,'Neither','Neither','#F2F4F5')]:
        fig.add_artist(Rectangle((x/190,(y-1.07)/108),3.2/190,2.14/108,transform=fig.transFigure,facecolor=c,edgecolor=MUTED,linewidth=.5))
        labelmm(fig,x+5.7,y,f'{lab} · {int((classes==k).sum())}',fontsize=8,va='center')
    covered=map_inset_checks(fig,axes,insets)
    export(fig,'Fig04_reallocation_and_membership',extra={'panels':2,'insets':'lower right of respective main maps','inset_overlap_map_area_m2':covered,'same_full_extent_and_scale':True,'same_inset_extent_and_scale':True,'category_counts':dict(pd.Series(classes).value_counts()),'diverging_palette_unchanged':True,'title_top_mm':103.5,'subtitle_top_mm':98.5,'legend_top_mm':14.14,'legend_note_baseline_mm':19.0})

def capture(module,fn):
    result={};old=module.export
    def keeper(fig,stem,main=True,extra=None):result.update(fig=fig,stem=stem,main=main,extra=extra)
    module.export=keeper
    try:fn()
    finally:module.export=old
    return result

def suppA():
    old=r.SEQ;r.SEQ=mpl.colormaps['cividis_r']
    item=capture(r,r.suppA);r.SEQ=old
    fig=item['fig'];fig.set_size_inches(190/25.4,98/25.4)
    a,b,c=fig.axes
    moveax(fig,a,16,23,71,63);moveax(fig,b,112,23,73,63);moveax(fig,c,112,12,73,2.4)
    for t,x in zip(fig.texts,[16,112]):t.set_position((x/190,94/98));t.set_va('top')
    a.get_legend().remove();hs,ls=a.get_legend_handles_labels()
    fig.legend(hs,ls,loc='center',bbox_to_anchor=(51.5/190,7.4/98),frameon=False,ncol=1,labelspacing=.35)
    item['extra'].update(palette='cividis_r',title_top_mm=94,plot_y_mm=23,plot_height_mm=63,formal_number_proposed='S1')
    export(**item)

def cumulative():
    item=capture(m,m.cumulative);fig=item['fig'];fig.set_size_inches(90/25.4,85/25.4)
    moveax(fig,fig.axes[0],17.1,13,68.4,66.96)
    item['extra'].update(formal_number_proposed='S2',plot_box_mm=[68.4,66.96])
    export(**item)

def concentration():
    item=capture(m,m.concentration);fig=item['fig'];fig.set_size_inches(190/25.4,106/25.4)
    a,b,c=fig.axes;moveax(fig,a,15,23,74,65);moveax(fig,b,115,23,70,65);moveax(fig,c,115,12,70,2.4)
    for t,x in zip(fig.texts[:2],[15,115]):t.set_position((x/190,102/106));t.set_va('top')
    fig.canvas.draw()
    column_label=b.get_xticklabels()[0].get_window_extent()
    column_center=(column_label.y0+column_label.y1)/2/fig.bbox.height
    fig.legends[0].set_bbox_to_anchor((52/190,column_center))
    fig.texts[2].set_position((15/190,6.4/106))
    item['extra'].update(formal_number_proposed='S3',palette='cividis',title_top_mm=102,plot_y_mm=23,plot_height_mm=65)
    export(**item)

def diagnostics():
    item=capture(m,m.diagnostics);fig=item['fig'];fig.set_size_inches(190/25.4,102/25.4)
    a,b=fig.axes;moveax(fig,a,35,23,67,67);moveax(fig,b,118,23,67,67)
    fig.legends[0].set_bbox_to_anchor((151.5/190,8.4/102))
    fig.texts[0].set_position((35/190,7.0/102));fig.texts[1].set_position((.025,1.8/102))
    fig.canvas.draw()
    boxes=[(ax.get_window_extent().width/fig.dpi*25.4,ax.get_window_extent().height/fig.dpi*25.4) for ax in [a,b]]
    assert all(abs(w-h)<1e-9 and abs(w-67)<1e-9 for w,h in boxes)
    item['extra'].update(formal_number_proposed='S4',plot_boxes_mm=boxes)
    export(**item)
