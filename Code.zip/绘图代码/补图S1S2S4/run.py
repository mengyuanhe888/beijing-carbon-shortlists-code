"""Redraw supplementary figures S1, S2 and S4 from saved CSVs; no model fitting."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True, help='完整的绘图输入目录。')
    parser.add_argument('--out', type=Path, required=True, help='资料包及输入目录以外的新输出目录。')
    parser.add_argument('--figures', nargs='+', choices=['S1', 'S2', 'S4'], default=['S1', 'S2', 'S4'])
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    inputs, out = args.inputs.expanduser().resolve(), args.out.expanduser().resolve()
    if not inputs.is_dir():
        parser.error(f'输入目录不存在：{inputs}')
    for protected in [inputs, source.parent.parent]:
        if out.is_relative_to(protected) or protected.is_relative_to(out):
            parser.error('输出目录必须位于代码和输入目录之外。')
    if out.exists():
        parser.error(f'输出目录已存在，请另选新目录：{out}')
    required = ['现用绘图明细/图3_空间份额与名单.csv', '现用绘图明细/图4b至g_七年保存汇总.csv',
        '现用绘图明细/图4a_35街道标签与频率.csv', '现用绘图明细/图5_预算算术_2022.csv',
        '现用绘图明细/图3f_累计份额.csv', '辅助核验/final_street_year_model_panel.csv',
        '辅助核验/street_frequencies_all_scopes.csv', '辅助核验/thermal_2022_all_scenarios.csv',
        '辅助核验/district_caps.csv', '辅助核验/bootstrap_optimization_status.csv',
        '辅助核验/bootstrap_continuation_audit.json',
        *['补图S1/' + s for s in ['Figure_3a_full_sample.csv', 'Figure_3ab_LOYO.csv', 'Figure_3c_VIF.csv', 'Figure_3d_bootstrap.csv']],
        *['边界/北京街道乡镇界.' + ext for ext in ['shp', 'shx', 'dbf', 'prj']]]
    missing = [p for p in required if not (inputs / p).is_file()]
    if missing:
        parser.error('缺少输入：\n' + '\n'.join(missing))
    out.mkdir(parents=True)
    # Archived drawing functions write relative to their own file. Copy them
    # and the inputs into this new run directory before importing any module.
    for name in ['redraw.py', 'moderate_grouping.py', 'refine_maps_supp.py', 'visual_theme.json']:
        shutil.copy2(source / name, out / name)
    shutil.copytree(source / '配色数据', out / '配色数据')
    shutil.copytree(inputs, out / '输入副本')
    for name in ['缓存/matplotlib', '缓存/tmp', 'QA/原尺寸预览', 'QA/灰阶', 'QA/色觉检查', '报告', '绘图明细', '候选补图', '主文候选']:
        (out / name).mkdir(parents=True, exist_ok=True)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(out))
    import redraw as r
    r.SEQ = r.mpl.colormaps['cividis']
    r.META['numeric_baseline'] = 'Saved CSVs supplied by --inputs; no model estimation or resampling in this run.'
    import refine_maps_supp as supp
    functions = {'S1': supp.suppA, 'S2': supp.cumulative, 'S4': supp.diagnostics}
    for name in dict.fromkeys(args.figures):
        functions[name]()
    r.js(r.META, out / 'QA/绘图机械检查.json')
    r.pd.DataFrame(r.CHECKS).to_csv(out / '报告/数值逐列核验.csv', index=False)
    hashes = {str(p.relative_to(inputs)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(inputs.rglob('*')) if p.is_file()}
    (out / '报告/输入SHA256.json').write_text(json.dumps(hashes, ensure_ascii=False, indent=2), encoding='utf-8')
    print('重绘完成。PDF、SVG、PNG位于：', out / '候选补图')


if __name__ == '__main__':
    main()
