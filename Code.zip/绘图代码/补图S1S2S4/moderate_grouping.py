"""User-approved moderate grouping. Saved-data redraw only; no model execution."""
from redraw import *
import shutil

def archive_superseded():
    archive=ROOT/'设计过程_不作为候选/补图合并前'
    archive.mkdir(parents=True,exist_ok=True)
    stems=['Supp_B_VIF','Supp_C_bootstrap_coefficients','Supp_D_cumulative_share','Supp_E_annual_concentration','Supp_F_concentration_matrix']
    for stem in stems:
        for folder,extensions in [('候选补图',['png','pdf','svg']),('QA/原尺寸预览',['png']),('QA/灰阶',['png']),('QA/色觉检查',['png'])]:
            for ext in extensions:
                p=ROOT/folder/(stem+'.'+ext)
                if p.exists():
                    dest=archive/folder/p.name;dest.parent.mkdir(parents=True,exist_ok=True)
                    if dest.exists():
                        n=1
                        while dest.with_name(dest.stem+f'_再绘{n}'+dest.suffix).exists():n+=1
                        dest=dest.with_name(dest.stem+f'_再绘{n}'+dest.suffix)
                    shutil.move(str(p),str(dest))
        p=ROOT/'图注'/(stem+'_中英文候选图注.md')
        if p.exists():
            dest=archive/'图注'/p.name;dest.parent.mkdir(exist_ok=True)
            if not dest.exists():shutil.move(str(p),str(dest))

def diagnostics():
    fig=figmm(190,107)
    a=fig.add_axes([35/190,26/107,67/190,67/107])
    b=fig.add_axes([118/190,26/107,67/190,67/107])
    a.set_box_aspect(1);b.set_box_aspect(1)
    y=np.arange(8);vals=vif.set_index('variable').loc[TERMS].VIF.to_numpy()
    a.hlines(y,0,vals,color=GRID,lw=1)
    a.scatter(vals,y,c=[ORANGE if v>10 else BLUE for v in vals],s=24,zorder=3)
    for yy,v in zip(y,vals):a.text(v+.4,yy,f'{v:.1f}',va='center',color=ORANGE if v>10 else INK)
    a.axvline(10,color=ORANGE,ls='--',lw=.7)
    a.set(xlim=(0,15.0),ylim=(7.5,-.5),xticks=[0,5,10,15],yticks=y,yticklabels=LABELS,xlabel='Variance inflation factor')
    a.tick_params(axis='y',length=0)
    b.axvline(0,color=MUTED,lw=.7,ls='--');grid(b,'x')
    for scope,offset,c,marker,ls,label in [('all_1000',-.10,BLUE,'o','-','All 1,000'),('success_only',.10,SKY,'s','--',f'Converged {final_success}')]:
        d=beta[beta.scope.eq(scope)].set_index('term').loc[TERMS]
        for yy,row in zip(y+offset,d.itertuples()):b.plot([row.ci_low,row.ci_high],[yy,yy],color=c,lw=1,ls=ls)
        b.scatter(d.bootstrap_mean,y+offset,s=25,marker=marker,facecolor=c if scope=='all_1000' else 'white',edgecolor=c,lw=.7,zorder=3,label=label)
    b.set(xlim=(-4.8,2.4),ylim=(7.5,-.5),xticks=[-4,-2,0,2],yticks=y,yticklabels=[],xlabel='Scaled coefficient')
    b.tick_params(axis='y',length=0)
    head(a,'a','Collinearity');head(b,'b','Coefficient uncertainty')
    hs,ls=b.get_legend_handles_labels()
    fig.legend(hs,ls,loc='center',bbox_to_anchor=(151.5/190,.098),ncol=2,frameon=False,columnspacing=1,handletextpad=.5)
    fig.text(35/190,.09,'Dashed line: VIF = 10',fontsize=8,color=MUTED)
    fig.text(.025,.022,f'Same eight covariates in both panels; all-run intervals retain {1000-final_success} nonconverged endpoints.',fontsize=8,color=MUTED)
    fig.canvas.draw();boxes=[]
    for ax in [a,b]:
        box=ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted());boxes.append([box.width*25.4,box.height*25.4])
        assert abs(box.width-box.height)<1e-10
    export(fig,'Supp_B_covariate_diagnostics',main=False,extra={'panels':2,'formal_number_proposed':'S2','variables':8,'plot_boxes_mm':boxes,'square_VIF_axes':True,'values_above_10_retained':int((vals>10).sum()),'scopes':[1000,final_success],'interval':'saved endpoints, 2.5th and 97.5th percentiles; no resampling','coefficient_scale':'saved reporting_scale; NTL multiplied by full-sample SD(log NTL), remaining scales 1'})

def cumulative():
    fig=figmm(90,93);ax=fig.add_axes([.19,.20,.76,.72])
    ax.plot([0,343],[0,100],color=GRID,ls='--',lw=.8,label='Uniform')
    for model in ['M1','M2','M4']:
        g=curves[curves.model.eq(model)].sort_values('rank');marker,ls=STYLES[model]
        ax.plot(np.r_[0,g['rank']],np.r_[0,g.cumulative_share_percent],color=COL[model],ls=ls,lw=1.1,label=model)
        value=float(g[g['rank'].eq(35)].cumulative_share_percent.iloc[0]);ax.scatter([35],[value],s=22,marker=marker,color=COL[model],edgecolor='white',lw=.5,zorder=5)
    ax.axvline(35,color=MUTED,ls='--',lw=.7);ax.text(40,5,'Top 35',rotation=90,va='bottom',fontsize=8,color=MUTED)
    ax.set(xlim=(0,343),ylim=(0,100),xticks=[0,100,200,300],yticks=[0,25,50,75,100],xlabel='Top-ranked subdistricts (n)',ylabel='Cumulative Beijing share (%)')
    hs=[legend_line(k) for k in ['M1','M2','M4']]+[Line2D([],[],ls='--',color=GRID,label='Uniform')]
    ax.legend(handles=hs,loc='lower right',frameon=False)
    export(fig,'Supp_C_cumulative_share',main=False,extra={'formal_number_proposed':'S3','year':2022,'streets_per_curve':343})

def concentration():
    fig=figmm(190,110)
    a=fig.add_axes([15/190,25/110,74/190,65/110]);b=fig.add_axes([115/190,25/110,70/190,65/110])
    x=annual.M4_concentration.to_numpy()*100;z=annual.M4prime_concentration.to_numpy()*100
    xx=np.r_[x,x.mean()];zz=np.r_[z,z.mean()];y=np.arange(8)+.5
    for yy,v,w in zip(y,xx,zz):a.plot([v,w],[yy,yy],color=GRID,lw=1.1)
    a.scatter(xx,y,color=ORANGE,marker='^',s=27,label='M4',zorder=3)
    a.scatter(zz,y,color=TEAL,marker='D',s=23,label='M4′',zorder=3)
    labels=[str(v) for v in annual.year]+['Mean']
    a.set(ylim=(8,0),yticks=y,yticklabels=labels,xlim=(40,50.5),xticks=[40,42,44,46,48,50],xlabel='Top-35 share of Beijing total (%)')
    a.tick_params(axis='y',length=0);grid(a,'x');a.axhline(7,color=GRID,lw=.7)
    models=['M1','M2','M4','EDGAR'];values0=annual[[k+'_concentration' for k in models]].to_numpy()*100
    values=np.vstack([values0,values0.mean(axis=0)]);norm=Normalize(25,51)
    b.pcolormesh(np.arange(5),np.arange(9),values,cmap=SEQ,norm=norm,edgecolors='none',rasterized=False)
    for i in range(8):
        for j in range(4):b.text(j+.5,i+.5,f'{values[i,j]:.1f}',ha='center',va='center',color=textcolor(SEQ(norm(values[i,j]))),weight='bold' if i==7 else 'normal')
    b.hlines(7,0,4,color='white',lw=2)
    b.set(xlim=(0,4),ylim=(8,0),xticks=np.arange(4)+.5,xticklabels=models,yticks=y,yticklabels=labels)
    b.tick_params(top=True,labeltop=True,bottom=False,labelbottom=False,length=0)
    for sp in b.spines.values():sp.set_visible(False)
    for ax in [a,b]:ax.get_yticklabels()[-1].set_weight('bold')
    fig.text(15/190,.963,'(a)  Energy vs electricity',weight='bold',fontsize=9,va='top')
    fig.text(115/190,.963,'(b)  Models and EDGAR',weight='bold',fontsize=9,va='top')
    hs,ls=a.get_legend_handles_labels();fig.legend(hs,ls,loc='center',bbox_to_anchor=(52/190,.864),frameon=False,ncol=2)
    colorbar(fig,[115/190,.12,70/190,.025],SEQ,norm,[25,35,45,51],['25','35','45','51'],'Top-35 share of Beijing total (%)')
    fig.text(15/190,.06,f'Means: M4 {x.mean():.1f}%; M4′ {z.mean():.1f}%.',fontsize=8,color=MUTED)
    csv(pd.DataFrame(values,columns=models).assign(year=labels),'补图D_集中度矩阵含均值.csv')
    csv(pd.DataFrame({'year':labels,'M4':xx,'M4prime':zz}),'补图D_集中度配对含均值.csv')
    export(fig,'Supp_D_concentration_comparison',main=False,extra={'panels':2,'formal_number_proposed':'S4','paired_years':7,'annual_matrix':'7 × 4 plus a mean row','added_display':'previously captioned paired means also displayed as Mean row'})

if __name__=='__main__':
    archive_superseded();diagnostics();cumulative();concentration()
    p=ROOT/'QA/绘图机械检查.json';old=json.loads(p.read_text())
    keep={k:v for k,v in old['figures'].items() if k.startswith('Fig') or k=='Supp_A_fit_and_LOYO'}
    keep.update(META['figures']);old['figures']={k:keep[k] for k in sorted(keep)}
    old['grouping']='8 main figures + 4 supplementary figures; all 19 original panels retained'
    js(old,p)
    print(json.dumps({'final_figures':len(keep),'VIF_axis_dimensions_mm':META['figures']['Supp_B_covariate_diagnostics']['plot_boxes_mm']},ensure_ascii=False))
