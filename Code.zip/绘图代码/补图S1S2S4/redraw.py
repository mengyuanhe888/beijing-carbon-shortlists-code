"""SCS split candidates: saved-data redraw only. No models or old plot modules imported.

Runtime: /opt/anaconda3/envs/carbon_emission/bin/python
All outputs, caches, and temporary files are contained in this script's directory.
"""
from pathlib import Path
import os, sys, json, hashlib, platform
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR'] = str(ROOT/'缓存/matplotlib')
os.environ['TMPDIR'] = str(ROOT/'缓存/tmp')
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize, SymLogNorm, LinearSegmentedColormap, to_rgba
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from matplotlib import font_manager
from PIL import Image
import fitz

D = ROOT/'输入副本/现用绘图明细'
S = ROOT/'输入副本/补图S1'
U = ROOT/'输入副本/辅助核验'
THEME=json.loads((ROOT/'visual_theme.json').read_text())
INK, MUTED, GRID = [THEME['neutral'][k] for k in ['ink','muted','grid']]
COL=THEME['models']
BLUE, SKY, ORANGE, TEAL = [COL[k] for k in ['M1','M2','M4','M4prime']]
STYLES = {'M1':('o','-'),'M2':('s','--'),'M4':('^',':')}
BLUES = THEME['cross_setting_counts']
# Exact source RGB arrays are archived, versioned by SHA. No package installation.
seq_source=np.loadtxt(ROOT/'配色数据/oslo.txt')[::-1]
SEQ=LinearSegmentedColormap.from_list('paper_oslo_r',seq_source,N=256)
SEQ=LinearSegmentedColormap.from_list('paper_oslo_r_trimmed',SEQ(np.linspace(.04,.93,256)),N=256)
mpl.colormaps.register(SEQ,name='paper_seq')
DIV=LinearSegmentedColormap.from_list('paper_vik',np.loadtxt(ROOT/'配色数据/vik.txt'),N=256)
DIV=LinearSegmentedColormap.from_list('paper_vik_trimmed',DIV(np.linspace(.10,.90,256)),N=256)
FONT = font_manager.findfont('Arial', fallback_to_default=False)
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial'],
    'font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':8,
    'ytick.labelsize':8,'legend.fontsize':8,'legend.title_fontsize':8,
    'axes.linewidth':.6,'axes.edgecolor':INK,'axes.labelcolor':INK,
    'xtick.color':INK,'ytick.color':INK,'text.color':INK,'xtick.major.width':.6,
    'ytick.major.width':.6,'xtick.major.size':3,'ytick.major.size':3,
    'lines.linewidth':1.1,'lines.markeredgewidth':.6,'patch.linewidth':.5,
    'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white',
    'axes.facecolor':'white','savefig.facecolor':'white','pdf.fonttype':42,
    'ps.fonttype':42,'svg.fonttype':'none','hatch.linewidth':.5})
META = {'numeric_baseline':'fixed-season August-to-next-April main results, 20260922; saved-data redraw only',
    'model_fits':0,'bootstrap_runs':0,'python':sys.executable,'python_version':platform.python_version(),
    'packages':{'numpy':np.__version__,'pandas':pd.__version__,'geopandas':gpd.__version__,'matplotlib':mpl.__version__},
    'font_path':FONT,'figures':{},'map_checks':{},'checks':{}}
CHECKS = []
def read(p): return pd.read_csv(p,float_precision='round_trip')
def js(x,p): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=lambda x:x.item() if hasattr(x,'item') else str(x)))
def csv(x,name):
    p=ROOT/'绘图明细'/name; x.to_csv(p,index=False,float_format='%.17g'); return p
def preserve(x,name,source):
    p=csv(x,name); y=read(p)
    for c in x.columns:
        a=x[c].reset_index(drop=True); b=y[c].reset_index(drop=True)
        numeric=pd.api.types.is_numeric_dtype(a) and not pd.api.types.is_bool_dtype(a)
        if numeric:
            err=float(np.max(np.abs(a.to_numpy()-b.to_numpy()))) if len(a) else 0
            ok=np.array_equal(a.to_numpy(),b.to_numpy(),equal_nan=True)
        else: err=None; ok=a.fillna('<NA>').astype(str).equals(b.fillna('<NA>').astype(str))
        CHECKS.append({'source':source,'candidate_data':name,'column':c,'rows':len(a),'numeric':numeric,'maximum_absolute_difference':err,'exact_values_equal':bool(ok)})
        assert ok,(name,c,err)
    return p
def figmm(w,h): return plt.figure(figsize=(w/25.4,h/25.4))
def head(ax,letter,label):
    ax.set_title(f'({letter})  {label}',loc='left',fontweight='bold',fontsize=9,pad=12)
def grid(ax,axis='y'): ax.grid(axis=axis,color=GRID,linewidth=.5,zorder=0); ax.set_axisbelow(True)
def legend_line(model,label=None):
    marker,ls=STYLES.get(model,('D','-'))
    return Line2D([],[],marker=marker,linestyle=ls,color=COL[model],markersize=4,label=label or model)
def textcolor(rgba):
    rgb=np.asarray(rgba[:3]); lin=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
    return INK if np.dot(lin,[.2126,.7152,.0722])>.38 else 'white'
def colorbar(fig,rect,cmap,norm,ticks,labels,label):
    cax=fig.add_axes(rect);cb=mpl.colorbar.ColorbarBase(cax,cmap=cmap,norm=norm,orientation='horizontal',ticks=ticks)
    if cb.solids is not None:
        cb.solids.set_rasterized(False)
        cb.solids.set_edgecolor('face')
    cb.set_ticklabels(labels);cb.set_label(label,labelpad=5);cb.outline.set_linewidth(.5)
    return cb
def export(fig,stem,main=True,extra=None):
    fig.canvas.draw();ren=fig.canvas.get_renderer();outside=[];sizes=[]
    for t in fig.findobj(mpl.text.Text):
        if t.get_visible() and t.get_text().strip():
            # Hidden axis tick objects do not count as rendered typography.
            if t.axes is not None and not t.axes.axison and t not in t.axes.texts: continue
            b=t.get_window_extent(ren);sizes.append(float(t.get_fontsize()))
            if b.x0<-.5 or b.y0<-.5 or b.x1>fig.bbox.width+.5 or b.y1>fig.bbox.height+.5:
                outside.append(t.get_text())
    dest=ROOT/('主文候选' if main else '候选补图')/stem
    dpi=(extra or {}).get('export_dpi',1000)
    for ext in ['pdf','svg','png']:
        fig.savefig(dest.with_suffix('.'+ext),dpi=dpi,bbox_inches=None,pad_inches=0,facecolor='white')
    # Lossless export optimization only: remove an entirely opaque alpha channel.
    # Pixel values and physical size remain identical to the rendered figure.
    if (extra or {}).get('optimize_opaque_png'):
        png=dest.with_suffix('.png')
        with Image.open(png) as im:
            assert im.mode=='RGBA' and im.getchannel('A').getextrema()==(255,255)
            rgb=im.convert('RGB');pixel_hash=hashlib.sha256(rgb.tobytes()).hexdigest()
            rgb.save(png,dpi=(dpi,dpi),optimize=True,compress_level=9)
        with Image.open(png) as im:
            assert hashlib.sha256(im.convert('RGB').tobytes()).hexdigest()==pixel_hash
    # Each PDF rendered at the stated physical size, 144 dpi = 2 screen pixels per pt.
    pdf=fitz.open(dest.with_suffix('.pdf'));page=pdf[0]
    pix=page.get_pixmap(dpi=144,alpha=False)
    preview=ROOT/'QA/原尺寸预览'/(stem+'.png');pix.save(preview)
    raster=len(page.get_images(full=True));draws=len(page.get_drawings())
    span_sizes=[float(s['size']) for b in page.get_text('dict')['blocks'] for ln in b.get('lines',[]) for s in ln.get('spans',[]) if s['text'].strip()]
    font_names=sorted({s['font'] for b in page.get_text('dict')['blocks'] for ln in b.get('lines',[]) for s in ln.get('spans',[])})
    pdf.close()
    Image.open(preview).convert('L').save(ROOT/'QA/灰阶'/(stem+'.png'))
    # Machado et al. (2009), full deuteranomaly; approximation in linear RGB.
    im=Image.open(preview).convert('RGB');a=np.asarray(im,dtype=float)/255
    lin=np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
    matrix=np.array([[.367322,.860646,-.227968],[.280085,.672501,.047413],[-.011820,.042940,.968881]])
    b=np.clip(lin@matrix.T,0,1);b=np.where(b<=.0031308,12.92*b,1.055*b**(1/2.4)-.055)
    Image.fromarray(np.uint8(np.clip(b,0,1)*255)).save(ROOT/'QA/色觉检查'/(stem+'.png'))
    META['figures'][stem]={'folder':dest.parent.name,'size_mm':np.round(fig.get_size_inches()*25.4,3).tolist(),
        'ordinary_font_min_pt':min(sizes),'pdf_font_range_pt':[min(span_sizes),max(span_sizes)],
        'pdf_fonts':font_names,'outside_canvas_labels':outside,'PNG_dpi':dpi,
        'raster_objects_in_PDF':raster,'vector_drawings_in_PDF':draws,
        'vector_status':'hybrid: raster polygon fills; editable text and vector boundaries' if raster else 'vector paths and editable text; no embedded raster',
        **(extra or {})}
    assert not outside,(stem,outside)
    assert min(span_sizes)>=(4.49 if (extra or {}).get('math_subscripts') else 7.99),(stem,min(span_sizes))
    plt.close(fig);print(stem,'exported',flush=True)

# ==================== Saved-data and geometry audit ====================
space=read(D/'图3_空间份额与名单.csv')
annual=read(D/'图4b至g_七年保存汇总.csv').sort_values('year')
names=read(D/'图4a_35街道标签与频率.csv').sort_values('rank')
budget=read(D/'图5_预算算术_2022.csv')
curves=read(D/'图3f_累计份额.csv')
full=read(S/'Figure_3a_full_sample.csv');loyo=read(S/'Figure_3ab_LOYO.csv')
vif=read(S/'Figure_3c_VIF.csv');beta=read(S/'Figure_3d_bootstrap.csv')
panel=read(U/'final_street_year_model_panel.csv');p22=panel[panel.year.eq(2022)]
assert space.street_id.is_unique and len(space)==343
assert len(names)==35 and names.street_id.is_unique and list(names['rank'])==list(range(1,36))
assert annual.year.tolist()==list(range(2016,2023))
m2=set(p22.nlargest(35,'w_m1').street_id);m4=set(p22.nlargest(35,'w_m3').street_id)
assert set(names.street_id)==m4
classes=np.select([space.street_id.isin(m2&m4),space.street_id.isin(m2-m4),space.street_id.isin(m4-m2)],['Both','M2 only','M4 only'],default='Neither')
assert np.array_equal(classes,space.selection_class)
assert (len(m2&m4),len(m2-m4),len(m4-m2))==(3,32,32)
freq=read(U/'street_frequencies_all_scopes.csv')
f=freq[freq.scope.eq('continued_all_1000')&freq.model.eq('M4')&freq.year.eq(2022)].set_index('street_id')
assert f.denominator.eq(1000).all()
assert np.array_equal(names.frequency,names.street_id.map(f.top35_frequency))
scen=read(U/'thermal_2022_all_scenarios.csv')
scen=scen[scen.year.eq(2022)&scen['lambda'].eq(1)&scen.constraint.eq('city_total_only')]
sets=[m4,set(p22.nlargest(35,'w_m4').street_id)]+[set(scen[scen.template.str.startswith(k)&scen.scenario_rank.le(35)].street_id) for k in ['EDGAR','ODIAC']]
assert all(len(s)==35 for s in sets)
cross=[sum(i in s for s in sets) for i in names.street_id]
assert np.array_equal(cross,names.cross_count)
assert np.array_equal(names.frequency.ge(.8)&names.cross_count.eq(4),names.bold_core)
initial=read(U/'bootstrap_optimization_status.csv')
continuation=json.loads((U/'bootstrap_continuation_audit.json').read_text())
assert initial['count'].sum()==1000
final_success = continuation['success_count']+continuation['continued_success_count']
assert final_success==continuation['final_success_count']
assert beta[beta.scope.eq('all_1000')].bootstrap_reps.eq(1000).all()
assert beta[beta.scope.eq('success_only')].bootstrap_reps.eq(final_success).all()
assert np.allclose(space.logdiff,np.log(space.w_m3)-np.log(space.w_m1),rtol=0,atol=1e-14)
boundary=gpd.read_file(ROOT/'输入副本/边界/北京街道乡镇界.shp')
boundary['street_id']=pd.to_numeric(boundary.PAC)
assert len(boundary)==343 and boundary.street_id.is_unique and boundary.crs is not None
assert boundary.geometry.is_valid.all() and not boundary.geometry.is_empty.any()
assert set(boundary.street_id)==set(space.street_id)
native_crs=str(boundary.crs)
streets=boundary[['street_id','geometry']].merge(space,on='street_id',validate='one_to_one').to_crs(32650)
districts=streets.dissolve(by='district_name')
raw=streets.total_bounds;dx=raw[2]-raw[0];dy=raw[3]-raw[1]
bounds=(raw[0]-.025*dx,raw[2]+.025*dx,raw[1]-.025*dy,raw[3]+.025*dy)
center=streets[streets.district_name.isin(['东城区','西城区'])].total_bounds
pad=2500
zoom=(center[0]-pad,center[2]+pad,center[1]-pad,center[3]+pad)
pooled=np.concatenate([space[c].to_numpy()*100 for c in ['w_m0','w_m1','w_m3']])
quantiles=np.array([0,.10,.25,.50,.75,.90,.975,1]);breaks=np.quantile(pooled,quantiles);positions=np.linspace(0,1,len(breaks))
for c in ['w_m0','w_m1','w_m3']:
    assert np.allclose(space[c+'_display'],np.interp(space[c]*100,breaks,positions),rtol=0,atol=1e-14)
META['map_checks']={'rows':343,'unique_IDs':343,'join_coverage':'343/343','valid_geometries':343,
    'source_CRS':native_crs,'display_CRS':str(streets.crs),'identical_full_extent_UTM_m':bounds,
    'identical_central_inset_extent_UTM_m':zoom,'pooled_quantiles':quantiles.tolist(),
    'pooled_share_breaks_percent':breaks.tolist(),'display_positions':positions.tolist(),
    'categorical_counts':pd.Series(classes).value_counts().to_dict(),'boundary_modified':False}
thresh={}
capfile=read(U/'district_caps.csv')
for k in ['EDGAR','ODIAC']:
    g=budget[budget.template.eq(k)]
    assert len(g.district_name.unique())==16
    assert not g.duplicated(['district_name','lambda']).any()
    err=np.max(np.abs(g.original_target_tCO2-g['lambda']*g.assigned_sector_at_lambda1_tCO2-g.remaining_budget_tCO2))
    assert err<1e-7
    starts=g.groupby('district_name')[['original_target_tCO2','assigned_sector_at_lambda1_tCO2']].first()
    rat=starts.original_target_tCO2/starts.assigned_sector_at_lambda1_tCO2
    lim=rat.idxmin();cap=float(rat.min());s=capfile[capfile.year.eq(2022)&capfile.template.str.startswith(k)].iloc[0]
    assert abs(cap-s.lambda_max_preserving_district)<1e-14 and lim==s.limiting_district_name
    thresh[k]={'cap':cap,'district':lim,'arithmetic_max_abs_error_tCO2':err,'negative_rows':int(g.remaining_budget_tCO2.lt(0).sum())}
assert thresh['EDGAR']['district']=='门头沟区' and thresh['ODIAC']['district']=='石景山区'
overlap_checks=[]
for yr,g in panel.groupby('year'):
    row=annual[annual.year.eq(yr)].iloc[0]
    for key,k in [('Top20_overlap',69),('Top10_overlap',35),('Top5_overlap',18)]:
        common=len(set(g.nlargest(k,'w_m3').street_id)&set(g.nlargest(k,'w_m4').street_id))
        assert abs(common/k-row[key])<1e-14
        overlap_checks.append({'year':yr,'fraction_label':key,'k':k,'common':common,'overlap':common/k})
    for label,field in [('M1','w_m0'),('M2','w_m1'),('M4','w_m3'),('M4prime','w_m4')]:
        assert abs(g.nlargest(35,field)[field].sum()-row[label+'_concentration'])<1e-14
META['checks']={'all35_complete':True,'frequency_denominator':1000,'initial_converged':continuation['success_count'],
    'continued_converged_additional':continuation['continued_success_count'],'final_converged':final_success,'exception_retained_all1000':1000-final_success,
    'core_names':names[names.bold_core].street_name.tolist(),
    'strata_counts':[int(names.frequency.ge(.8).sum()),int((names.frequency.ge(.5)&names.frequency.lt(.8)).sum()),int(names.frequency.lt(.5).sum())],
    'all4_by_stratum':[int((names.frequency.ge(.8)&names.cross_count.eq(4)).sum()),int((names.frequency.ge(.5)&names.frequency.lt(.8)&names.cross_count.eq(4)).sum()),int((names.frequency.lt(.5)&names.cross_count.eq(4)).sum())],
    'thresholds':thresh,'M4_EDGAR_overlap_7yr':float(annual.M4_EDGAR_Top35.mean()),
    'random_overlap_expectation':35/343,'M4_concentration_7yr':float(annual.M4_concentration.mean()),
    'M4prime_concentration_7yr':float(annual.M4prime_concentration.mean()),
    'M4_concentration_2022':float(annual.iloc[-1].M4_concentration),'M4_M4prime_overlap_7yr':float(annual.Top10_overlap.mean()),
    'M4_M4prime_common_2022':len(sets[0]&sets[1])}
csv(pd.DataFrame(overlap_checks),'名单长度与年度共同数_核验.csv')
csv(pd.DataFrame({'quantile':quantiles,'share_percent':breaks,'display_position':positions}),'地图共用色标.csv')

# Explicit per-column equality audit of every source table, including columns moved to different figures.
for data,name,source in [
    (space,'新图3与4_343街道.csv','图3_空间份额与名单.csv'),
    (names,'新图5_35街道_中文拼音ID对照.csv','图4a_35街道标签与频率.csv'),
    (annual,'新图6与7及补图E与F_七年保存汇总.csv','图4b至g_七年保存汇总.csv'),
    (budget,'新图8_全部预算曲线.csv','图5_预算算术_2022.csv'),
    (curves,'补图D_累计份额.csv','图3f_累计份额.csv'),
    (full,'补图A_全样本.csv','Figure_3a_full_sample.csv'),
    (loyo,'补图A_LOYO.csv','Figure_3ab_LOYO.csv'),
    (vif,'补图B_VIF.csv','Figure_3c_VIF.csv'),
    (beta,'补图C_两套系数区间.csv','Figure_3d_bootstrap.csv')]: preserve(data,name,source)

def extent(ax,ext=bounds):
    ax.set_xlim(ext[0],ext[1]);ax.set_ylim(ext[2],ext[3]);ax.set_xticks([]);ax.set_yticks([]);ax.set_aspect('equal');ax.axis('off')
def boundaries(ax):
    districts.boundary.plot(ax=ax,color='#536473',alpha=.44,linewidth=.55,zorder=3)
def sharemap(ax,col,ext=bounds):
    streets.plot(ax=ax,column=col+'_display',cmap=SEQ,vmin=0,vmax=1,
        edgecolor=to_rgba('#597281',.18),linewidth=.5,rasterized=True,zorder=1)
    boundaries(ax);extent(ax,ext)
def diffmap(ax,ext=bounds):
    limit=float(np.ceil(np.abs(space.logdiff).max()))
    norm=SymLogNorm(linthresh=.25,linscale=.85,vmin=-limit,vmax=limit,base=10,clip=True)
    streets.plot(ax=ax,column='logdiff',cmap=DIV,norm=norm,edgecolor=to_rgba('#597281',.18),linewidth=.5,rasterized=True,zorder=1)
    streets[streets.logdiff.gt(0)].plot(ax=ax,facecolor='none',edgecolor=to_rgba('#596571',.55),linewidth=0,hatch='/',zorder=2)
    boundaries(ax);extent(ax,ext);return norm
def classmap(ax,ext=bounds):
    streets.plot(ax=ax,color='#F2F4F5',edgecolor=to_rgba('#597281',.14),linewidth=.5,rasterized=True,zorder=1)
    for k,c in [('Both','#354558'),('M2 only',SKY),('M4 only',ORANGE)]:
        streets[streets.selection_class.eq(k)].plot(ax=ax,color=c,edgecolor=to_rgba('#597281',.22),linewidth=.5,rasterized=True,zorder=2)
    boundaries(ax);extent(ax,ext)
def zoom_frame(ax):
    ax.add_patch(Rectangle((zoom[0],zoom[2]),zoom[1]-zoom[0],zoom[3]-zoom[2],facecolor='none',edgecolor=INK,linewidth=.6,linestyle=(0,(2,2)),zorder=5))

def main3():
    fig=figmm(190,125)
    for i,(model,col) in enumerate([('M1','w_m0'),('M2','w_m1'),('M4','w_m3')]):
        left=.025+i*.327
        ax=fig.add_axes([left,.41,.302,.53]);sharemap(ax,col);head(ax,'abc'[i],model+' · 2022');zoom_frame(ax)
        ins=fig.add_axes([left+.04,.18,.222,.18]);sharemap(ins,col,zoom)
        ins.text(.5,1.015,'Central-area detail',transform=ins.transAxes,ha='center',va='bottom',fontsize=8)
    fmt=lambda v:f'{v:.2f}' if v<1 else f'{v:.1f}'
    colorbar(fig,[.10,.095,.83,.018],mpl.colormaps['cividis'],Normalize(0,1),positions[1:],[fmt(v) for v in breaks[1:]],'Share of Beijing total (%) · pooled empirical-quantile scale')
    export(fig,'Fig03_spatial_allocation',extra={'panels':3,'central_detail':'same Dongcheng/Xicheng-derived extent, unchanged data; not an additional analytical panel'})

def main4():
    fig=figmm(190,125)
    a=fig.add_axes([.035,.39,.445,.53]);b=fig.add_axes([.525,.39,.445,.53])
    norm=diffmap(a);classmap(b);head(a,'a','Within-district reallocation');head(b,'b','Top-35 list membership')
    for ax in [a,b]: zoom_frame(ax)
    for x,fn in [(.15,diffmap),(.64,classmap)]:
        ax=fig.add_axes([x,.20,.215,.15]);fn(ax,zoom)
        ax.text(.5,1.02,'Central-area detail',transform=ax.transAxes,ha='center',va='bottom',fontsize=8)
    colorbar(fig,[.055,.10,.39,.018],DIV,norm,[-10,-1,0,1,10],['−10','−1','0','1','10'],'ln(M4 share / M2 share)')
    fig.text(.06,.155,'Hatching: positive log change',fontsize=8,color=MUTED)
    handles=[Patch(facecolor=c,edgecolor='#566268',linewidth=.5,label=f'{lab} (n = {int((classes==key).sum())})') for key,lab,c in [('Both','Both','#344D5D'),('M2 only','M2 only',SKY),('M4 only','M4 only',ORANGE),('Neither','Neither','#F0F2F3')]]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.754,.018),ncol=2,frameon=False,handlelength=1.2,columnspacing=1.0,labelspacing=.5)
    export(fig,'Fig04_reallocation_and_membership',extra={'panels':2,'positive_hatch_preserved':True,'all_categories_counts':dict(pd.Series(classes).value_counts())})

def main5():
    fig=figmm(140,200);ax=fig.add_axes([.29,.10,.54,.81])
    for lo,hi,c in [(0,50,'#F7F7F5'),(50,80,'#EEF2F4'),(80,100,'#E1E9ED')]:ax.axvspan(lo,hi,color=c,zorder=0)
    for v in [50,80]:ax.axvline(v,color=MUTED,linewidth=.6,linestyle=(0,(3,2)),zorder=1)
    yy=np.arange(35);xx=names.frequency.to_numpy()*100
    colors=[BLUES[int(i)-1] for i in names.cross_count]
    ax.hlines(yy,0,xx,color=colors,linewidth=1.1,zorder=2)
    ax.scatter(xx,yy,c=colors,s=22,edgecolor=INK,linewidth=.5,zorder=3)
    ax.set(xlim=(0,100),ylim=(34.8,-.8),xticks=[0,25,50,80,100],yticks=yy,yticklabels=names.axis_label,xlabel='Bootstrap selection frequency (%)')
    ax.tick_params(axis='y',length=0,pad=5)
    for t,core in zip(ax.get_yticklabels(),names.bold_core): t.set_weight('bold' if core else 'normal')
    for y,x in zip(yy,xx):ax.text(1.035,y,f'{x:.1f}',transform=ax.get_yaxis_transform(),va='center',ha='left')
    for y,n in zip(yy,names.cross_count):ax.text(1.205,y,str(n),transform=ax.get_yaxis_transform(),va='center',ha='center')
    ax.text(1.035,1.018,'%',transform=ax.transAxes,ha='left',va='bottom')
    ax.text(1.205,1.018,'n/4',transform=ax.transAxes,ha='center',va='bottom')
    for x,label in [(25,'<50%'),(65,'50–<80%'),(90,'≥80%')]: ax.text(x,1.018,label,transform=ax.get_xaxis_transform(),ha='center',va='bottom')
    handles=[Line2D([],[],marker='o',ls='',color=INK,markerfacecolor=c,markeredgewidth=.5,markersize=4,label=str(i+1)) for i,c in enumerate(BLUES)]
    fig.legend(handles=handles,title='Selections across four settings',loc='upper center',bbox_to_anchor=(.57,.999),ncol=4,frameon=False,handletextpad=.5,columnspacing=1.4)
    fig.text(.03,.038,'Ranks follow the 2022 M4 baseline; all 1,000 runs retained.',fontsize=8)
    fig.text(.03,.016,'Bold names: frequency ≥80% and selected in all four settings.',fontsize=8)
    export(fig,'Fig05_list_stability',extra={'records':35,'rank_order':'M4 baseline rank 1–35','frequency_scope':'continued_all_1000','separate_cross_setting_encoding':True})

def main6():
    fig=figmm(190,88);a=fig.add_axes([.09,.19,.36,.66]);b=fig.add_axes([.57,.19,.405,.66])
    years=annual.year.to_numpy()
    a.plot(years,annual.M4_M4prime_spearman,marker='o',color=TEAL,markersize=4)
    avg=float(annual.M4_M4prime_spearman.mean());a.axhline(avg,color=MUTED,ls='--',lw=.7)
    a.set(xlim=(2015.6,2022.4),ylim=(.96,1),xticks=years,yticks=[.96,.97,.98,.99,1],ylabel='Street-level Spearman correlation',xlabel='Year')
    a.yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.3f'));grid(a);head(a,'a','Rank agreement')
    a.text(.04,.94,f'Seven-year mean: {avg:.3f}',transform=a.transAxes,va='top')
    for key,k,c,mark in [('Top20_overlap',69,BLUE,'o'),('Top10_overlap',35,ORANGE,'s'),('Top5_overlap',18,TEAL,'^')]:
        b.plot(years,annual[key]*100,marker=mark,color=c,markersize=4,label=f'Top {k} ({key.split("_")[0][3:]}%)')
    b.set(xlim=(2015.6,2022.4),ylim=(40,100),xticks=years,yticks=[40,60,80,100],ylabel='List overlap (%)',xlabel='Year');grid(b);head(b,'b','List agreement')
    b.legend(loc='lower left',frameon=False,ncol=1,handlelength=1.8)
    b.text(.98,.98,f'Top 35 mean: {annual.Top10_overlap.mean()*100:.1f}%\n2022: {len(sets[0]&sets[1])} / 35',transform=b.transAxes,ha='right',va='top',linespacing=1.4)
    export(fig,'Fig06_energy_electricity',extra={'panels':2,'list_lengths':[69,35,18],'annual_points':7})

def main7():
    fig=figmm(190,94);a=fig.add_axes([.08,.22,.37,.62]);b=fig.add_axes([.565,.22,.405,.62])
    years=annual.year.to_numpy()
    for model in ['M1','M2','M4']:
        marker,ls=STYLES[model]
        a.plot(years,annual[model+'_EDGAR_spearman'],color=COL[model],marker=marker,ls=ls,markersize=4,label=model)
    a.set(xlim=(2015.6,2022.4),ylim=(-.02,1),xticks=years,yticks=[0,.2,.4,.6,.8,1],xlabel='Year',ylabel='Street-level Spearman correlation')
    a.yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.3f'));grid(a);head(a,'a','Rank agreement with EDGAR')
    a.legend(loc='upper left',frameon=False,ncol=3,handlelength=1.3,columnspacing=1.1)
    offsets=np.linspace(-.23,.05,7); summary=[]
    for i,model in enumerate(['M1','M2','M4']):
        vals=annual[model+'_EDGAR_Top35'].to_numpy()*100
        b.vlines(i+.30,vals.min(),vals.max(),color=COL[model],lw=1.0,zorder=1)
        b.hlines([vals.min(),vals.max()],i+.25,i+.35,color=COL[model],lw=.7)
        b.scatter(i+offsets,vals,color=COL[model],s=18,marker=STYLES[model][0],edgecolor='white',linewidth=.5,zorder=3)
        b.hlines(np.median(vals),i+.20,i+.40,color=INK,lw=1.0,zorder=4)
        b.scatter([i+.30],[vals.mean()],marker='D',s=28,facecolor='white',edgecolor=INK,lw=.7,zorder=5)
        b.text(i,67,f'Mean {vals.mean():.1f}%',ha='center',va='center',color=INK)
        summary.append({'model':model,'min':vals.min(),'max':vals.max(),'median':np.median(vals),'mean':vals.mean(),'annual_n':7})
    rnd=35/343*100;b.axhline(rnd,color=MUTED,ls='--',lw=.7,zorder=0)
    b.text(.025,rnd-1.7,'Random expectation 10.2%',transform=b.get_yaxis_transform(),ha='left',va='top',fontsize=8,color=MUTED)
    b.set(xlim=(-.5,2.5),ylim=(0,72),xticks=[0,1,2],xticklabels=['M1','M2','M4'],yticks=[0,20,40,60],ylabel='Top-35 overlap with EDGAR (%)');grid(b);head(b,'b','Annual lists and summaries')
    fig.text(.566,.094,'Points, left to right: 2016–2022; whiskers: range.',fontsize=8)
    fig.text(.566,.044,'Black bar: median; open diamond: seven-year mean.',fontsize=8)
    csv(pd.DataFrame(summary),'新图7b_年度分布汇总.csv')
    export(fig,'Fig07_EDGAR_comparison',extra={'panels':2,'annual_points_per_model':7,'random_line':'expectation, not a significance threshold'})

def main8():
    fig=figmm(190,101);axes=[fig.add_axes([.09,.205,.375,.62]),fig.add_axes([.575,.205,.375,.62])]
    lower=float(budget.remaining_budget_tCO2.min()/1e6)*1.2;upper=float(budget.remaining_budget_tCO2.max()/1e6)*1.08
    focal={'EDGAR':'Mentougou','ODIAC':'Shijingshan'}
    for i,(ax,k) in enumerate(zip(axes,['EDGAR','ODIAC'])):
        c=BLUE if i==0 else ORANGE;t=thresh[k]['cap']*100
        ax.axvspan(t,100,color='#F5F0EB',zorder=0)
        g=budget[budget.template.eq(k)]
        for district,d in g.groupby('district_name'):
            d=d.sort_values('lambda');focus=district==thresh[k]['district']
            ax.plot(d['lambda']*100,d.remaining_budget_tCO2/1e6,color=c if focus else '#9AA6AE',lw=1.3 if focus else .65,alpha=1 if focus else .58,zorder=3 if focus else 1)
        ax.axhline(0,color=INK,lw=.8,zorder=4);ax.axvline(t,color=c,ls=(0,(4,2)),lw=.85,zorder=4)
        ax.scatter([t],[0],s=25,facecolor='white',edgecolor=c,lw=.85,zorder=5)
        ax.text(t-.5,1.015,f'{t:.2f}%',transform=ax.get_xaxis_transform(),ha='right',va='bottom',color=c,weight='bold')
        ax.annotate(focal[k]+' reaches zero',xy=(t,0),xytext=(97,2.0),ha='right',va='bottom',fontsize=8,color=c,arrowprops={'arrowstyle':'-','lw':.7,'color':c})
        ax.set(xlim=(0,100),ylim=(lower,upper),xticks=[0,20,40,60,80,100],xlabel='Power-and-heat budget treated (%)')
        grid(ax);ax.set_title(f'({"ab"[i]}) {k} all-sector template',loc='left',weight='bold',pad=29)
        ax.text(.03,.955,'16 district budgets',transform=ax.transAxes,va='top',fontsize=8,color=MUTED)
    axes[0].set_ylabel('Remaining district budget (million tonnes CO2)')
    axes[1].set_ylabel('Remaining district budget (million tonnes CO2)')
    fig.text(.52,.085,'Negative values are retained: the corresponding district constraint is violated.',ha='center',fontsize=8,color=MUTED)
    fig.text(.52,.039,'Template arithmetic only; the maps do not locate observed power plants.',ha='center',fontsize=8,color=MUTED)
    export(fig,'Fig08_district_budget_compatibility',extra={'panels':2,'curves_per_panel':16,'shared_ylim_million_tCO2':[lower,upper],'negative_values_retained':True})

TERMS=['log_ntl','log_poi_density','log_road_density','log_building_density','green_ratio','industrial_ratio','commercial_ratio','residential_ratio']
LABELS=['NTL','POI density','Road density','Building cover','Green ratio','Industrial','Commercial','Residential']
def suppA():
    fig=figmm(190,101);a=fig.add_axes([.08,.23,.345,.65]);b=fig.add_axes([.55,.23,.425,.65])
    f=full.copy();f['V']=f.short_label
    l=loyo.copy();l['V']=l.block.map(dict(zip(full.block,full.short_label)))
    order=['V1','V2','V3','V4','V5'];f=f.set_index('V').loc[order];av=l.groupby('V').mean(numeric_only=True).loc[order]
    yy=np.arange(5)
    a.hlines(yy,f.mean_spearman,av.mean_spearman,color=GRID,lw=1.0)
    a.scatter(f.mean_spearman,yy-.08,s=24,color=BLUE,label='Full sample',zorder=3)
    a.scatter(av.mean_spearman,yy+.08,s=24,facecolor='white',edgecolor=ORANGE,marker='s',lw=.8,label='LOYO mean',zorder=3)
    a.set(xlim=(.67,1),ylim=(4.35,-.35),xticks=[.7,.8,.9,1],yticks=yy,yticklabels=order,xlabel='District Spearman correlation');grid(a,'x')
    a.xaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%.3f'))
    fig.text(.08,.966,'(a) District fit',weight='bold',fontsize=9)
    a.legend(loc='upper left',bbox_to_anchor=(-.01,-.18),frameon=False,ncol=1,borderaxespad=0)
    mat=l.pivot(index='heldout_year',columns='V',values='mean_l1').loc[list(range(2016,2023)),order]
    values=np.vstack([mat.to_numpy(),mat.mean().to_numpy()]);norm=Normalize(.14,.46);cmap=SEQ
    b.pcolormesh(np.arange(6),np.arange(9),values,cmap=cmap,norm=norm,edgecolors='none',rasterized=False)
    for i in range(8):
        for j in range(5): b.text(j+.5,i+.5,f'{values[i,j]:.3f}',ha='center',va='center',color=textcolor(cmap(norm(values[i,j]))),weight='bold' if i==7 else 'normal')
    b.hlines(7,0,5,color='white',lw=2)
    b.set(xlim=(0,5),ylim=(8,0),xticks=np.arange(5)+.5,xticklabels=order,yticks=np.arange(8)+.5,yticklabels=[str(y) for y in range(2016,2023)]+['Mean'])
    b.tick_params(top=True,labeltop=True,bottom=False,labelbottom=False,length=0)
    for s in b.spines.values():s.set_visible(False)
    fig.text(.55,.966,'(b) LOYO L1 error',weight='bold',fontsize=9)
    colorbar(fig,[.55,.137,.425,.027],cmap,norm,[.14,.25,.35,.46],['0.140','0.250','0.350','0.460'],'District-share L1 error')
    csv(pd.DataFrame(values,index=[str(y) for y in range(2016,2023)]+['Mean'],columns=order).reset_index(names='heldout_year'),'补图A_热图含均值.csv')
    export(fig,'Supp_A_fit_and_LOYO',main=False,extra={'panels':2,'formal_number_proposed':'S1','heatmap_values':40})

def suppB():
    # Square plotting box, not equal numerical units on categorical and VIF axes.
    fig=figmm(110,90);ax=fig.add_axes([35/110,19/90,67/110,67/90])
    ax.set_box_aspect(1)
    vals=vif.set_index('variable').loc[TERMS].VIF.to_numpy();y=np.arange(8)
    ax.hlines(y,0,vals,color=GRID,lw=1.0)
    ax.scatter(vals,y,c=[ORANGE if v>10 else BLUE for v in vals],s=24,zorder=3)
    for yy,v in zip(y,vals):ax.text(v+.4,yy,f'{v:.1f}',va='center',color=ORANGE if v>10 else INK)
    ax.axvline(10,color=ORANGE,ls='--',lw=.7,zorder=1)
    ax.set(xlim=(0,13.8),ylim=(7.5,-.5),xticks=[0,5,10],yticks=y,yticklabels=LABELS,xlabel='Variance inflation factor')
    ax.tick_params(axis='y',length=0)
    fig.text(35/110,.041,'Dashed line: VIF = 10',fontsize=8,color=MUTED)
    fig.canvas.draw()
    box=ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
    assert abs(box.width-box.height)<1e-10
    export(fig,'Supp_B_VIF',main=False,extra={'formal_number_proposed':'S2','variables':8,'values_above_10_retained':int((vals>10).sum()),'plot_box_mm':[box.width*25.4,box.height*25.4],'square_axes':True})

def suppC():
    fig=figmm(140,104);ax=fig.add_axes([.245,.23,.70,.70]);yy=np.arange(8)
    ax.axvline(0,color=MUTED,lw=.7,ls='--',zorder=0);grid(ax,'x')
    for scope,offset,c,marker,ls,label in [('all_1000',-.10,BLUE,'o','-','All runs (1,000)'),('success_only',.10,SKY,'s','--',f'Converged ({final_success})')]:
        d=beta[beta.scope.eq(scope)].set_index('term').loc[TERMS]
        for y,row in zip(yy+offset,d.itertuples()):ax.plot([row.ci_low,row.ci_high],[y,y],color=c,lw=1.0,ls=ls)
        ax.scatter(d.bootstrap_mean,yy+offset,s=25,marker=marker,facecolor=c if scope=='all_1000' else 'white',edgecolor=c,lw=.7,zorder=3,label=label)
    ax.set(xlim=(-4.8,2.4),ylim=(7.6,-.6),xticks=[-4,-2,0,2],yticks=yy,yticklabels=LABELS,xlabel='Scaled coefficient (mean and 95% percentile interval)')
    ax.tick_params(axis='y',length=0)
    handles,labels=ax.get_legend_handles_labels()
    fig.legend(handles,labels,loc='center',bbox_to_anchor=(.61,.095),frameon=False,ncol=2,columnspacing=1.4)
    fig.text(.035,.03,f'All-run intervals retain {1000-final_success} nonconverged optimization endpoints.',fontsize=8)
    export(fig,'Supp_C_bootstrap_coefficients',main=False,extra={'formal_number_proposed':'S3','scopes':[1000,final_success],'interval':'saved 2.5th and 97.5th percentiles; no resampling','coefficient_scale':'saved reporting_scale; NTL multiplied by saved SD(log NTL), remaining scales 1'})

def suppD():
    fig=figmm(90,93);ax=fig.add_axes([.19,.20,.76,.72])
    ax.plot([0,343],[0,100],color=GRID,ls='--',lw=.8,label='Uniform')
    for model in ['M1','M2','M4']:
        g=curves[curves.model.eq(model)].sort_values('rank');marker,ls=STYLES[model]
        ax.plot(np.r_[0,g['rank']],np.r_[0,g.cumulative_share_percent],color=COL[model],ls=ls,lw=1.1,label=model)
        value=float(g[g['rank'].eq(35)].cumulative_share_percent.iloc[0]);ax.scatter([35],[value],s=22,marker=marker,color=COL[model],edgecolor='white',lw=.5,zorder=5)
    ax.axvline(35,color=MUTED,ls='--',lw=.7)
    ax.text(40,5,'Top 35',rotation=90,va='bottom',fontsize=8,color=MUTED)
    ax.set(xlim=(0,343),ylim=(0,100),xticks=[0,100,200,300],yticks=[0,25,50,75,100],xlabel='Top-ranked subdistricts (n)',ylabel='Cumulative Beijing share (%)')
    handles=[legend_line(k) for k in ['M1','M2','M4']]+[Line2D([],[],ls='--',color=GRID,label='Uniform')]
    ax.legend(handles=handles,loc='lower right',frameon=False,ncol=1,handlelength=2)
    export(fig,'Supp_D_cumulative_share',main=False,extra={'formal_number_proposed':'S4','year':2022,'streets_per_curve':343})

def suppE():
    fig=figmm(90,90);ax=fig.add_axes([.18,.19,.77,.65]);y=np.arange(7)
    x=annual.M4_concentration.to_numpy()*100;z=annual.M4prime_concentration.to_numpy()*100
    for yy,xx,zz in zip(y,x,z):ax.plot([xx,zz],[yy,yy],color=GRID,lw=1.1)
    ax.scatter(x,y,color=ORANGE,marker='^',s=27,label='M4',zorder=3)
    ax.scatter(z,y,color=TEAL,marker='D',s=23,label='M4′',zorder=3)
    ax.set(ylim=(6.5,-.5),yticks=y,yticklabels=annual.year.astype(str),xlim=(40,50.5),xticks=[40,42,44,46,48,50],xlabel='Top-35 share of Beijing total (%)');grid(ax,'x');ax.tick_params(axis='y',length=0)
    fig.legend(loc='upper center',bbox_to_anchor=(.59,.985),ncol=2,frameon=False,columnspacing=2)
    fig.text(.18,.043,f'Seven-year means: M4 {x.mean():.1f}%; M4′ {z.mean():.1f}%.',fontsize=8)
    export(fig,'Supp_E_annual_concentration',main=False,extra={'formal_number_proposed':'S5','paired_years':7})

def suppF():
    fig=figmm(90,102);ax=fig.add_axes([.19,.24,.77,.65]);models=['M1','M2','M4','EDGAR']
    vals=annual[[k+'_concentration' for k in models]].to_numpy()*100;values=np.vstack([vals,vals.mean(axis=0)])
    norm=Normalize(25,50);cmap=SEQ
    ax.pcolormesh(np.arange(5),np.arange(9),values,cmap=cmap,norm=norm,edgecolors='none',rasterized=False)
    for i in range(8):
        for j in range(4):ax.text(j+.5,i+.5,f'{values[i,j]:.1f}',ha='center',va='center',color=textcolor(cmap(norm(values[i,j]))),weight='bold' if i==7 else 'normal')
    ax.hlines(7,0,4,color='white',lw=2)
    ax.set(xlim=(0,4),ylim=(8,0),xticks=np.arange(4)+.5,xticklabels=models,yticks=np.arange(8)+.5,yticklabels=[str(y) for y in annual.year]+['Mean'])
    ax.tick_params(top=True,labeltop=True,bottom=False,labelbottom=False,length=0)
    for sp in ax.spines.values():sp.set_visible(False)
    colorbar(fig,[.19,.153,.77,.028],cmap,norm,[25,35,45,50],['25','35','45','50'],'Top-35 share of Beijing total (%)')
    csv(pd.DataFrame(values,columns=models).assign(year=[str(y) for y in annual.year]+['Mean']),'补图F_集中度矩阵含均值.csv')
    export(fig,'Supp_F_concentration_matrix',main=False,extra={'formal_number_proposed':'S6','annual_matrix':'7 × 4 plus a mean row'})

if __name__=='__main__':
    raise SystemExit('Use run_c4.py for the approved current 10-figure set; legacy drawing entry points are not active.')
    requested=set(sys.argv[1:])
    for fn in [main3,main4,main5,main6,main7,main8,suppA,suppB,suppC,suppD,suppE,suppF]:
        if not requested or fn.__name__ in requested:fn()
    old=ROOT/'QA/绘图机械检查.json'
    if requested and old.exists():
        prev=json.loads(old.read_text());prev['figures'].update(META['figures']);META['figures']=prev['figures']
    js(META,old)
    pd.DataFrame(CHECKS).to_csv(ROOT/'报告/拆分前后逐列数值核验.csv',index=False)
    js({'checks':META['checks'],'map_checks':META['map_checks'],'column_checks':len(CHECKS),'all_columns_equal':all(c['exact_values_equal'] for c in CHECKS)},ROOT/'报告/关键口径核验.json')
    print(json.dumps({'figures':len(META['figures']),'column_checks':len(CHECKS),'all_columns_equal':True,'model_fits':0},ensure_ascii=False),flush=True)
