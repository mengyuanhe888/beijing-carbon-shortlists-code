"""Run the saved single-column Fig. 1 drawing script in a new directory."""
from pathlib import Path
import argparse
import importlib.util
import os
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', required=True, type=Path, help='含1.数据文件夹的项目根目录。')
    parser.add_argument('--out', required=True, type=Path, help='项目之外的新输出目录。')
    args = parser.parse_args()
    project, out = args.project_root.expanduser().resolve(), args.out.expanduser().resolve()
    source = Path(__file__).resolve().parent
    for protected in [project, source.parent.parent]:
        if out.is_relative_to(protected) or protected.is_relative_to(out):
            parser.error('输出目录必须位于项目和绘图代码之外。')
    if out.exists():
        parser.error('输出目录已存在，请另选新目录。')
    required = ['1.数据文件夹/11.基础地图/北京市/北京市_哥白尼DEM_公众号遥感之家.tif',
        *['1.数据文件夹/08.街道矢量边界地图文件/北京街道乡镇界.' + ext for ext in ['shp', 'shx', 'dbf', 'prj']]]
    missing = [p for p in required if not (project / p).is_file()]
    if missing:
        parser.error('缺少输入：\n' + '\n'.join(missing))
    if importlib.util.find_spec('rasterio') is None:
        parser.error('缺少rasterio；请在同一Python环境安装本目录requirements-extra.txt，连同通用requirements-figures.txt。')
    out.mkdir(parents=True)
    shutil.copy2(source / 'draw_fig1_single_column.py', out / 'draw_fig1_single_column.py')
    shutil.copytree(source / '来源副本', out / '来源副本')
    env = dict(os.environ, SCS_PROJECT_ROOT=str(project), PYTHONDONTWRITEBYTECODE='1')
    subprocess.run([sys.executable, str(out / 'draw_fig1_single_column.py')], env=env, check=True)


if __name__ == '__main__':
    main()
