#!/usr/bin/env python3
"""Candidate SCS Figure 1: quiet Beijing-only topographic study-area map.

Use CARBON_PROJECT_ROOT to identify the study project and --output for an empty
output folder. PDF save DPI is explicit so the DEM is embedded at 600 ppi.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import warnings
from itertools import combinations
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-fig01-candidate")

import geopandas as gpd
import matplotlib as mpl
import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import rasterio
import rasterio.mask
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.font_manager import findfont, FontProperties
from matplotlib.patches import Polygon, Rectangle
from PIL import Image
from pyproj import Transformer
from rasterio.features import geometry_mask
from rasterio.transform import array_bounds
from rasterio.warp import Resampling, calculate_default_transform, reproject
from shapely import force_2d, make_valid
from shapely.geometry import box as shapely_box, mapping


PROJECT_ROOT = Path(os.environ.get("CARBON_PROJECT_ROOT", Path(__file__).resolve().parents[4]))
FREEZE = PROJECT_ROOT / "2.论文复现包"
INPUT_STREETS = PROJECT_ROOT / "1.数据文件夹/08.街道矢量边界地图文件/北京街道乡镇界.shp"
INPUT_DEM = PROJECT_ROOT / "1.数据文件夹/11.基础地图/北京市/北京市_哥白尼DEM_公众号遥感之家.tif"
INPUT_MAP_QA = PROJECT_ROOT / '2.论文复现包/3.结果/3.处理结果/空间元数据/map_and_weights_QA.json'

BUILD_DIR = Path(__file__).resolve().parent
import argparse
_parser = argparse.ArgumentParser(description=__doc__)
_parser.add_argument('--output', type=Path, required=True, help='新的空输出目录')
OUTPUT_DIR = _parser.parse_args().output
if OUTPUT_DIR.exists() and any(OUTPUT_DIR.iterdir()): raise FileExistsError('输出目录必须为空')
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
PNG_OUT = OUTPUT_DIR / "Figure_1_candidate_study_area.png"
PDF_OUT = OUTPUT_DIR / "Figure_1_candidate_study_area.pdf"
SVG_OUT = OUTPUT_DIR / "Figure_1_candidate_study_area.svg"
MANIFEST_OUT = OUTPUT_DIR / "Figure_1_candidate_manifest.json"

# Archival/delivery locations are recorded for reproducibility.  The plotting
# script writes only to the explicit --output directory; copying follows QA.
CANONICAL_FIGURE_DIR = FREEZE / "2.图表/图片"
CANONICAL_CODE_OUT = FREEZE / "1.code/图片代码/正文图来源代码/fig01_study_area_candidate.py"
DELIVERY_PNG = PROJECT_ROOT / "2.论文复现包/2.图表/图片/图01_研究区.png"

DISPLAY_CRS = "EPSG:32650"
FIGSIZE_IN = (6.70, 6.70)  # 170.18 x 170.18 mm; designed at publication size.
FONT_FAMILY = "Arial"
FONT_DIRECT_PT = 8.0
FONT_CENTRAL_PT = 7.0
FONT_TICK_PT = 7.5
FONT_LEGEND_PT = 7.0
STREET_LW = 0.50
DISTRICT_LW = 0.70
MUNICIPAL_LW = 1.05
RASTER_DPI = 600

DISTRICT_EN = {
    "东城区": "Dongcheng",
    "西城区": "Xicheng",
    "朝阳区": "Chaoyang",
    "丰台区": "Fengtai",
    "石景山区": "Shijingshan",
    "海淀区": "Haidian",
    "门头沟区": "Mentougou",
    "房山区": "Fangshan",
    "通州区": "Tongzhou",
    "顺义区": "Shunyi",
    "昌平区": "Changping",
    "大兴区": "Daxing",
    "怀柔区": "Huairou",
    "平谷区": "Pinggu",
    "密云区": "Miyun",
    "延庆区": "Yanqing",
}

# Hand-placed in lon/lat to prevent the dense central-district labels from colliding.
LABEL_LONLAT = {
    "Yanqing": (115.98, 40.46),
    "Huairou": (116.55, 40.61),
    "Miyun": (116.96, 40.48),
    "Pinggu": (117.17, 40.15),
    "Shunyi": (116.67, 40.16),
    "Changping": (116.22, 40.24),
    "Mentougou": (115.87, 39.96),
    "Fangshan": (115.89, 39.72),
    "Daxing": (116.39, 39.61),
    "Tongzhou": (116.83, 39.83),
    "Haidian": (116.20, 40.035),
    "Shijingshan": (116.04, 39.905),
    "Fengtai": (116.24, 39.805),
    "Xicheng": (116.295, 39.945),
    "Dongcheng": (116.455, 39.875),
    "Chaoyang": (116.615, 39.955),
}

CENTRAL = {"Haidian", "Shijingshan", "Fengtai", "Xicheng", "Dongcheng", "Chaoyang"}

TERRAIN_CMAP = LinearSegmentedColormap.from_list(
    "muted_beijing_terrain",
    [
        (0.00, "#E8F2F0"),
        (0.18, "#B8D5CF"),
        (0.36, "#94BDAE"),
        (0.53, "#B6B287"),
        (0.69, "#A38162"),
        (0.84, "#765144"),
        (1.00, "#3E2B2A"),
    ],
    N=256,
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def clean_vector(path: Path) -> gpd.GeoDataFrame:
    gdf = gpd.read_file(path)
    if gdf.crs is None:
        raise ValueError(f"Missing CRS: {path}")
    gdf = gdf.loc[gdf.geometry.notna() & ~gdf.geometry.is_empty].copy()
    gdf.geometry = gdf.geometry.map(lambda geom: make_valid(force_2d(geom)))
    if (~gdf.geometry.is_valid).any():
        raise ValueError(f"Invalid geometries remain in {path}")
    return gdf


def derive_district(streets: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    out = streets.copy()
    out["district_cn"] = out["ASCRIPTION"].astype(str).str.extract(r"北京市(.+?区)", expand=False)
    missing = out["district_cn"].isna()
    if missing.any():
        raise ValueError(f"Cannot derive district for {int(missing.sum())} streets")
    district = out.dissolve(by="district_cn", as_index=False)
    district["district_en"] = district["district_cn"].map(DISTRICT_EN)
    if len(district) != 16 or district["district_en"].isna().any():
        raise ValueError(f"District audit failed: n={len(district)}")
    return district


def load_dem(beijing_wgs, target_crs: str, resolution_m: float = 75.0):
    with rasterio.open(INPUT_DEM) as src:
        source_crs = src.crs
        source_shape = (src.height, src.width)
        source_bounds = tuple(src.bounds)
        source_nodata = src.nodata

        full = src.read(1, masked=True)
        full_valid = full.compressed()
        raw_min = float(full_valid.min())
        raw_max = float(full_valid.max())
        p02, p98 = [float(v) for v in np.quantile(full_valid, [0.02, 0.98])]

        clipped, clipped_transform = rasterio.mask.mask(
            src,
            [mapping(beijing_wgs)],
            crop=True,
            filled=False,
        )
        clipped = clipped[0].astype("float32")
        cbounds = array_bounds(clipped.shape[0], clipped.shape[1], clipped_transform)
        dst_transform, dst_width, dst_height = calculate_default_transform(
            source_crs,
            target_crs,
            clipped.shape[1],
            clipped.shape[0],
            *cbounds,
            resolution=resolution_m,
        )
        dst = np.full((dst_height, dst_width), np.nan, dtype="float32")
        reproject(
            source=clipped.filled(np.nan),
            destination=dst,
            src_transform=clipped_transform,
            src_crs=source_crs,
            src_nodata=np.nan,
            dst_transform=dst_transform,
            dst_crs=target_crs,
            dst_nodata=np.nan,
            resampling=Resampling.bilinear,
        )

    beijing_target = gpd.GeoSeries([beijing_wgs], crs="EPSG:4326").to_crs(target_crs).iloc[0]
    inside = geometry_mask(
        [mapping(beijing_target)],
        out_shape=dst.shape,
        transform=dst_transform,
        invert=True,
    )
    dst[~inside] = np.nan
    valid = dst[np.isfinite(dst)]
    if valid.size == 0:
        raise ValueError("Reprojected DEM contains no valid pixels")
    stats = {
        "source_crs": str(source_crs),
        "source_shape": list(source_shape),
        "source_bounds": list(source_bounds),
        "source_nodata": source_nodata,
        "source_min": raw_min,
        "source_max": raw_max,
        "source_p02": p02,
        "source_p98": p98,
        "display_crs": target_crs,
        "display_resolution_m": resolution_m,
        "display_shape": list(dst.shape),
        "beijing_min_after_reprojection": float(valid.min()),
        "beijing_max_after_reprojection": float(valid.max()),
    }
    return dst, dst_transform, raw_min, raw_max, stats


def dem_rgba(dem: np.ndarray, vmin: float, vmax: float) -> np.ndarray:
    valid = np.isfinite(dem)
    fill = float(np.nanmedian(dem))
    z = np.where(valid, dem, fill)
    norm = Normalize(vmin=vmin, vmax=vmax, clip=True)
    base = TERRAIN_CMAP(norm(z))[..., :3]
    gy, gx = np.gradient(z, 75.0, 75.0)
    slope = np.pi / 2.0 - np.arctan(np.hypot(gx, gy))
    aspect = np.arctan2(-gx, gy)
    az = math.radians(315.0)
    alt = math.radians(43.0)
    shade = np.sin(alt) * np.sin(slope) + np.cos(alt) * np.cos(slope) * np.cos(az - aspect)
    shade = (shade - np.nanpercentile(shade[valid], 2)) / (
        np.nanpercentile(shade[valid], 98) - np.nanpercentile(shade[valid], 2)
    )
    shade = np.clip(shade, 0.0, 1.0)
    # Preserve the elevation hues while restoring enough local contrast for the
    # western and northern ridges to remain legible at journal-print size.
    rgb = np.clip(base * (0.74 + 0.36 * shade[..., None]), 0.0, 1.0)
    alpha = np.where(valid, 1.0, 0.0)
    return np.dstack([rgb, alpha])


def add_north_arrow(ax, x: float, y: float, size: float, label_size: float) -> None:
    left = np.array([[x, y], [x - size * 0.42, y - size], [x, y - size * 0.72]])
    right = np.array([[x, y], [x + size * 0.42, y - size], [x, y - size * 0.72]])
    ax.add_patch(Polygon(left, transform=ax.transAxes, facecolor="#111111", edgecolor="#111111", lw=0.50, zorder=20))
    ax.add_patch(Polygon(right, transform=ax.transAxes, facecolor="white", edgecolor="#111111", lw=0.50, zorder=20))
    ax.text(x, y + size * 0.12, "N", transform=ax.transAxes, ha="center", va="bottom", fontsize=label_size, weight="bold", color="#111111", zorder=21)


def fmt_lon(value: float) -> str:
    degree = int(value)
    minute = int(round((value - degree) * 60))
    if minute == 60:
        degree += 1
        minute = 0
    return f"{degree}°{minute:02d}′E"


def fmt_lat(value: float) -> str:
    degree = int(value)
    minute = int(round((value - degree) * 60))
    if minute == 60:
        degree += 1
        minute = 0
    return f"{degree}°{minute:02d}′N"


def add_projected_ticks(ax, transformer: Transformer) -> None:
    lon_values = [115.5, 116.0, 116.5, 117.0, 117.5]
    lat_values = [39.5, 40.0, 40.5, 41.0]
    x_ticks = [transformer.transform(lon, 39.43)[0] for lon in lon_values]
    y_ticks = [transformer.transform(115.42, lat)[1] for lat in lat_values]
    ax.set_xticks(x_ticks)
    ax.set_xticklabels([fmt_lon(v) for v in lon_values], fontsize=FONT_TICK_PT)
    ax.set_yticks(y_ticks)
    ax.set_yticklabels([fmt_lat(v) for v in lat_values], fontsize=FONT_TICK_PT, rotation=90, va="center")
    ax.tick_params(axis="both", which="major", direction="out", length=3.0, width=0.6, pad=3, colors="#2D3336")
    ax.tick_params(top=False, labeltop=False, right=False, labelright=False)


def add_scale_bar(ax, x0: float, y0: float, segment_km: float = 25.0, nseg: int = 3):
    seg = segment_km * 1000.0
    height = 1200.0
    text_artists = []
    for i in range(nseg):
        ax.add_patch(
            Rectangle(
                (x0 + i * seg, y0),
                seg,
                height,
                facecolor="#111111" if i % 2 == 0 else "white",
                edgecolor="#111111",
                linewidth=0.5,
                zorder=30,
            )
        )
    for i in range(nseg + 1):
        xpos = x0 + i * seg
        ax.plot([xpos, xpos], [y0, y0 + height * 1.45], color="#111111", lw=0.55, zorder=31)
        label = f"{int(i * segment_km)}"
        if i == nseg:
            label += " km"
        text_artists.append(ax.text(xpos, y0 - 1650, label, ha="center", va="top", fontsize=FONT_TICK_PT, color="#20272B", zorder=31))
    return text_artists


def overlap_pairs(artists, renderer):
    boxes = []
    for artist in artists:
        bbox = artist.get_window_extent(renderer=renderer).expanded(1.01, 1.06)
        boxes.append((artist.get_text(), bbox))
    overlaps = []
    for (name_a, box_a), (name_b, box_b) in combinations(boxes, 2):
        if box_a.overlaps(box_b):
            overlaps.append(f"{name_a}|{name_b}")
    return overlaps


def main() -> None:
    warnings.filterwarnings("ignore", message="Measured.*geometry")
    for path in [INPUT_STREETS, INPUT_DEM]:
        if not path.exists():
            raise FileNotFoundError(path)

    streets = clean_vector(INPUT_STREETS).to_crs("EPSG:4326")
    districts = derive_district(streets)
    if len(streets) != 343 or streets["PAC"].duplicated().any():
        raise ValueError("Expected 343 unique street/township PAC codes")
    # Hash every shapefile component, not just geometry; source files stay read-only.
    input_paths = sorted(INPUT_STREETS.parent.glob(INPUT_STREETS.stem + ".*")) + [INPUT_DEM]
    hashes_before = {str(p): sha256(p) for p in input_paths}
    source_streets = gpd.read_file(INPUT_STREETS)
    source_geometry_qa = {
        "row_count": len(source_streets),
        "null_geometry": int(source_streets.geometry.isna().sum()),
        "empty_geometry": int(source_streets.geometry.is_empty.sum()),
        "invalid_geometry": int((~source_streets.geometry.is_valid).sum()),
        "key_duplicates": {k: int(source_streets[k].duplicated().sum()) for k in ["OBJECTID", "FID", "ELEMID", "ENTIID", "PAC"]},
        "source_crs": str(source_streets.crs),
        "source_PRODATE_counts": source_streets["PRODATE"].value_counts().to_dict(),
        "geometry_operation": "force_2d/make_valid in memory; all source geometries already valid; no file writes",
        "district_join": "343/343 derive from ASCRIPTION; 16/16 English labels matched",
    }

    study_wgs = districts.geometry.union_all()
    streets_p = streets.to_crs(DISPLAY_CRS)
    districts_p = districts.to_crs(DISPLAY_CRS)
    study_p = districts_p.geometry.union_all()
    dem, dem_transform, dem_min, dem_max, dem_stats = load_dem(study_wgs, DISPLAY_CRS)
    rgba = dem_rgba(dem, dem_min, dem_max)
    dbounds = array_bounds(dem.shape[0], dem.shape[1], dem_transform)
    dem_extent = [dbounds[0], dbounds[2], dbounds[1], dbounds[3]]

    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [FONT_FAMILY],
            "font.size": 7.0,
            "axes.linewidth": 0.65,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )

    font_file = findfont(FontProperties(family=FONT_FAMILY), fallback_to_default=False)
    fig = plt.figure(figsize=FIGSIZE_IN, facecolor="white", dpi=100)
    ax_b = fig.add_axes([0.073, 0.063, 0.906, 0.918])

    # Beijing study area only (no larger-area locator): DEM is raster; administrative boundaries, labels and cartographic elements remain vector.
    # Neutral warm off-white separates the study-area outline without competing
    # with the teal low-elevation end of the DEM palette.
    ax_b.set_facecolor("#F5F6F4")
    ax_b.imshow(rgba, extent=dem_extent, origin="upper", interpolation="bilinear", zorder=1)
    # Three boundary levels are drawn with distinct widths so the analysis-unit
    # hierarchy is legible without competing with the DEM relief.
    streets_p.boundary.plot(ax=ax_b, color="#566268", linewidth=STREET_LW, alpha=0.38, zorder=3)
    districts_p.boundary.plot(ax=ax_b, color="#303B40", linewidth=DISTRICT_LW, alpha=0.92, zorder=5)
    gpd.GeoSeries([study_p], crs=DISPLAY_CRS).boundary.plot(ax=ax_b, color="#151C20", linewidth=MUNICIPAL_LW, zorder=6)

    minx, miny, maxx, maxy = districts_p.total_bounds
    # Small framing margin only; no geography outside the studied municipality is drawn.
    ax_b.set_xlim(minx - 3500.0, maxx + 3500.0)
    ax_b.set_ylim(miny - 3500.0, maxy + 3500.0)
    ax_b.set_aspect("equal", adjustable="box")
    for spine in ax_b.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.65)
        spine.set_edgecolor("#303A3E")

    ll_to_utm = Transformer.from_crs("EPSG:4326", DISPLAY_CRS, always_xy=True)
    add_projected_ticks(ax_b, ll_to_utm)
    add_north_arrow(ax_b, 0.945, 0.925, 0.052, 8.0)

    district_label_artists = []
    label_leaders = []
    for name, (lon, lat) in LABEL_LONLAT.items():
        x, y = ll_to_utm.transform(lon, lat)
        fs = FONT_CENTRAL_PT if name in CENTRAL else FONT_DIRECT_PT
        district_geom = districts_p.loc[districts_p["district_en"].eq(name), "geometry"].iloc[0]
        label_point = gpd.points_from_xy([x], [y])[0]
        target = district_geom.representative_point()
        needs_leader = not district_geom.covers(label_point)
        if needs_leader:
            label_leaders.append(name)
        artist = ax_b.annotate(
            name,
            xy=(target.x, target.y) if needs_leader else (x, y),
            xytext=(x, y),
            textcoords="data",
            arrowprops={"arrowstyle": "-", "color": "#30373A", "lw": 0.5, "shrinkA": 2.0, "shrinkB": 1.0} if needs_leader else None,
            ha="center",
            va="center",
            fontsize=fs,
            color="#30373A",
            weight="normal",
            zorder=20,
            path_effects=[pe.withStroke(linewidth=1.55, foreground="white", alpha=0.95)],
        )
        district_label_artists.append(artist)

    # A 50-km scale bar fits the blank southwest corner without covering the study area.
    scale_bar_x0 = minx + 4000.0
    scale_bar_y0 = miny + 2500.0
    scale_bar_text_artists = add_scale_bar(ax_b, scale_bar_x0, scale_bar_y0, segment_km=25.0, nseg=2)

    # Compact elevation legend in the lower-right blank space, away from Pinggu/Tongzhou.
    cax = ax_b.inset_axes([0.904, 0.105, 0.021, 0.225])
    sm = mpl.cm.ScalarMappable(norm=Normalize(vmin=dem_min, vmax=dem_max), cmap=TERRAIN_CMAP)
    elevation_ticks = [dem_min, 500.0, 1000.0, 1500.0, 2000.0, dem_max]
    elevation_ticks = sorted({float(v) for v in elevation_ticks if dem_min <= v <= dem_max})
    cb = fig.colorbar(sm, cax=cax, orientation="vertical", ticks=elevation_ticks)
    cb.ax.set_yticklabels([f"{int(value)}" for value in elevation_ticks])
    cb.ax.tick_params(labelsize=FONT_LEGEND_PT, width=0.50, length=2.2, pad=2)
    cb.outline.set_linewidth(0.50)
    cb.outline.set_edgecolor("#42494C")
    cax.set_title("Elevation (m)", fontsize=FONT_LEGEND_PT, pad=5.0, color="#202629")

    # Boundary-hierarchy legend: Beijing municipal outline (thick), district
    # boundary (medium), street/township boundary (thin). These widths mirror the
    # actual drawn lines so the analysis-unit levels are unambiguous.
    boundary_handles = [
        Line2D([0], [0], color="#151C20", lw=MUNICIPAL_LW, label="Beijing municipal boundary"),
        Line2D([0], [0], color="#303B40", lw=DISTRICT_LW, label="District boundary (16)"),
        Line2D([0], [0], color="#566268", lw=STREET_LW, label="Street / township boundary (343)"),
    ]
    bleg = ax_b.legend(
        handles=boundary_handles,
        loc="upper left",
        bbox_to_anchor=(0.014, 0.979),
        frameon=True,
        fancybox=False,
        framealpha=0.94,
        borderpad=0.32,
        handlelength=1.7,
        handletextpad=0.45,
        labelspacing=0.26,
        fontsize=FONT_LEGEND_PT,
    )
    bleg.get_frame().set_facecolor("white")
    bleg.get_frame().set_edgecolor("#D3D5D5")
    bleg.get_frame().set_linewidth(0.50)

    # Render once so bounding boxes are available for QA before export.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    label_overlaps = overlap_pairs(district_label_artists, renderer)
    clipped_text = []
    fig_box = fig.bbox
    for artist in district_label_artists:
        box = artist.get_window_extent(renderer=renderer)
        if not fig_box.contains(box.x0, box.y0) or not fig_box.contains(box.x1, box.y1):
            clipped_text.append(artist.get_text())
    scale_bar_inside_panel = True
    for artist in scale_bar_text_artists:
        box = artist.get_window_extent(renderer=renderer)
        if not ax_b.bbox.contains(box.x0, box.y0) or not ax_b.bbox.contains(box.x1, box.y1):
            scale_bar_inside_panel = False
    scale_bar_footprint = shapely_box(scale_bar_x0, scale_bar_y0 - 2200.0, scale_bar_x0 + 50000.0, scale_bar_y0 + 1500.0)
    scale_bar_overlaps_study_area = bool(scale_bar_footprint.intersects(study_p))

    all_figure_text_clipped = []
    for artist in fig.findobj(match=lambda obj: isinstance(obj, mpl.text.Text)):
        if not artist.get_text().strip() or not artist.get_visible():
            continue
        box = artist.get_window_extent(renderer=renderer)
        if not fig_box.contains(box.x0, box.y0) or not fig_box.contains(box.x1, box.y1):
            all_figure_text_clipped.append(artist.get_text())

    fig.savefig(PNG_OUT, dpi=RASTER_DPI, facecolor="white", bbox_inches=None, pad_inches=0.0)
    fig.savefig(PDF_OUT, dpi=RASTER_DPI, facecolor="white", bbox_inches=None, pad_inches=0.0)
    fig.savefig(SVG_OUT, dpi=RASTER_DPI, facecolor="white", bbox_inches=None, pad_inches=0.0)
    plt.close(fig)

    with Image.open(PNG_OUT) as im:
        png_size = list(im.size)
        png_dpi = im.info.get("dpi", (None, None))

    try:
        import fitz

        pdf_doc = fitz.open(PDF_OUT)
        pdf_pages = len(pdf_doc)
        page_rect = pdf_doc[0].rect
        pdf_page_points = [float(page_rect.width), float(page_rect.height)]
        pdf_doc.close()
    except Exception as exc:  # pragma: no cover - manifest still records the failure.
        pdf_pages = None
        pdf_page_points = None
        warnings.warn(f"PDF QA unavailable: {exc}")

    map_qa = None
    if INPUT_MAP_QA.exists():
        map_qa = json.loads(INPUT_MAP_QA.read_text(encoding="utf-8"))

    qa_checks = {
        "street_count_343": len(streets) == 343,
        "district_count_16": len(districts) == 16,
        "street_geometries_valid": bool(streets.geometry.is_valid.all()),
        "district_geometries_valid": bool(districts.geometry.is_valid.all()),
        "dem_source_range_unchanged": dem_min == -47.0 and dem_max == 2293.0,
        "district_label_overlap_count": len(label_overlaps),
        "displaced_label_leaders": label_leaders,
        "district_labels_clipped": clipped_text,
        "scale_bar_inside_panel": scale_bar_inside_panel,
        "scale_bar_overlaps_study_area": scale_bar_overlaps_study_area,
        "all_figure_text_clipped": all_figure_text_clipped,
        "colorbar_right_edge_axes_fraction": 0.925,
        "colorbar_not_at_right_frame": 0.925 < 0.95,
        "bottom_longitude_left_latitude_only": True,
        "equal_aspect_no_map_stretching": True,
        "png_expected_pixel_size": png_size == [int(round(FIGSIZE_IN[0] * RASTER_DPI)), int(round(FIGSIZE_IN[1] * RASTER_DPI))],
        "pdf_single_page": pdf_pages == 1,
    }
    qa_status = "PASS" if all(
        [
            qa_checks["street_count_343"],
            qa_checks["district_count_16"],
            qa_checks["street_geometries_valid"],
            qa_checks["district_geometries_valid"],
            qa_checks["dem_source_range_unchanged"],
            qa_checks["district_label_overlap_count"] == 0,
            len(qa_checks["district_labels_clipped"]) == 0,
            qa_checks["scale_bar_inside_panel"],
            not qa_checks["scale_bar_overlaps_study_area"],
            len(qa_checks["all_figure_text_clipped"]) == 0,
            qa_checks["colorbar_not_at_right_frame"],
            qa_checks["png_expected_pixel_size"],
            qa_checks["pdf_single_page"],
        ]
    ) else "REVIEW"

    manifest = {
        "figure_id": "Figure 1 SCS study-area revision",
        "created_by": Path(__file__).name,
        "input_files": [{"path": str(p), "sha256": sha256(p)} for p in input_paths],
        "source_crs": {"streets": str(source_streets.crs), "dem": dem_stats["source_crs"]},
        "display_crs": DISPLAY_CRS,
        "counts": {"streets": len(streets), "districts": len(districts)},
        "source_geometry_qa": source_geometry_qa,
        "source_hashes_before": hashes_before,
        "source_hashes_unchanged": hashes_before == {str(p): sha256(p) for p in input_paths},
        "font_file": font_file,
        "font_size_range_pt": [FONT_CENTRAL_PT, 8.0],
        "map_extent_projected": [*ax_b.get_xlim(), *ax_b.get_ylim()],
        "study_bbox_wgs84": list(study_wgs.bounds),
        "map_scope": "Only Beijing study-area geometry and terrain; national locator and connector lines removed",
        "dem": dem_stats,
        "scale_bar": "0-50 km in two 25-km segments",
        "coordinate_labels": "longitude bottom; latitude left; degree-minute format",
        "map_content": "DEM, Beijing outer boundary, 16 district boundaries, and 343 street/township analysis-unit boundaries",
        "map_and_weights_QA_source": str(INPUT_MAP_QA) if INPUT_MAP_QA.exists() else None,
        "map_and_weights_QA_snapshot": map_qa,
        "outputs": {
            "png": {"path": str(PNG_OUT), "sha256": sha256(PNG_OUT), "pixel_size": png_size, "dpi_metadata": png_dpi},
            "pdf": {"path": str(PDF_OUT), "sha256": sha256(PDF_OUT), "pages": pdf_pages, "page_points": pdf_page_points},
            "svg": {"path": str(SVG_OUT), "sha256": sha256(SVG_OUT)},
            "code": {"path": str(Path(__file__).resolve()), "sha256": sha256(Path(__file__).resolve())},
        },
        "archival_targets": {
            "canonical_figure_directory": str(CANONICAL_FIGURE_DIR),
            "canonical_code": str(CANONICAL_CODE_OUT),
            "standardized_image_copy": str(DELIVERY_PNG),
        },
        "qa_checks": qa_checks,
        "district_label_overlap_pairs": label_overlaps,
        "qa_status": qa_status,
        "caption_en": "Figure 1. Study area and topographic setting of Beijing. The candidate uses a muted, luminance-ordered hypsometric scale; boundaries and labels are unchanged.",
        "caption_zh": "图1 北京市研究区地形及街道（乡镇）分析单元。边界由粗到细依次表示北京市研究区边界、16个区界和343个街道（乡镇）界。所有图层采用WGS 84 / UTM 50N（EPSG:32650），地形来自原始哥白尼DEM并按75 m双线性重采样及既有阴影处理显示。地图线条界定研究区域，并不一定表示公认的国家边界。",
        "map_lines_disclaimer_en": "Map lines delineate study areas and do not necessarily depict accepted national boundaries.",
        "important_note": "The PDF retains vector boundaries/text and embeds the DEM as a raster layer; source data were read-only and were not modified.",
    }
    MANIFEST_OUT.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"outputs": manifest["outputs"], "qa_status": qa_status, "qa_checks": qa_checks}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
