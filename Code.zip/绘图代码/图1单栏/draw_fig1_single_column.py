"""Fig1 layout-only re-export at native single-column size. No model execution.
Original DEM preparation functions loaded verbatim from the frozen source AST.
All writes confined to this script directory; original inputs read only.
"""
from pathlib import Path
import ast, os, sys, json, hashlib, platform
ROOT=Path(__file__).resolve().parent
P=Path(os.environ['SCS_PROJECT_ROOT']).expanduser().resolve()
for folder in ['缓存/matplotlib','缓存/tmp','QA']: (ROOT/folder).mkdir(parents=True,exist_ok=True)
os.environ['MPLCONFIGDIR']=str(ROOT/'缓存/matplotlib');os.environ['TMPDIR']=str(ROOT/'缓存/tmp')
sys.dont_write_bytecode=True

def bounded_write(event,args):
    if event != 'open' or not args or not isinstance(args[0],(str,bytes,os.PathLike)): return
    p,mode,flags=args
    writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
    if writing and not Path(os.fsdecode(p)).resolve().is_relative_to(ROOT): raise PermissionError(f'Write outside output directory: {p}')
sys.addaudithook(bounded_write)
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np, geopandas as gpd, fitz
from PIL import Image
from pyproj import Transformer
from rasterio.transform import array_bounds
from itertools import combinations

SHAPE=P/'1.数据文件夹/08.街道矢量边界地图文件/北京街道乡镇界.shp'
DEM=P/'1.数据文件夹/11.基础地图/北京市/北京市_哥白尼DEM_公众号遥感之家.tif'
SOURCE=ROOT/'来源副本/fig01_study_area_candidate.py'
PALETTE=ROOT/'来源副本/oslo.txt'
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
protected=[SOURCE,PALETTE,DEM,*sorted(SHAPE.parent.glob(SHAPE.stem+'.*'))]
before={str(p):digest(p) for p in protected}
(ROOT/'QA/输入SHA256_执行前.json').write_text(json.dumps(before,indent=2,ensure_ascii=False))
# No original top-level path handling, argparse, exports, or main is executed.
tree=ast.parse(SOURCE.read_text())
funcs={'clean_vector','derive_district','load_dem','dem_rgba','add_north_arrow','fmt_lon','fmt_lat'}
body=[]
for n in tree.body:
    if isinstance(n,(ast.Import,ast.ImportFrom)): body.append(n)
    elif isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DISTRICT_EN' for t in n.targets):body.append(n)
    elif isinstance(n,ast.FunctionDef) and n.name in funcs:body.append(n)
ns={'__name__':'original_data_functions','INPUT_DEM':DEM}
exec(compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])),str(SOURCE),'exec'),ns)
seq=LinearSegmentedColormap.from_list('paper_oslo_r',np.loadtxt(PALETTE)[::-1],N=256)
seq=LinearSegmentedColormap.from_list('paper_oslo_r_trimmed',seq(np.linspace(.04,.93,256)),N=256)
ns['TERRAIN_CMAP']=seq
streets=ns['clean_vector'](SHAPE).to_crs('EPSG:4326')
districts=ns['derive_district'](streets)
assert len(streets)==343 and streets.PAC.is_unique and len(districts)==16
assert streets.is_valid.all() and districts.is_valid.all()
study= districts.geometry.union_all()
crs='EPSG:32650'
s=streets.to_crs(crs); d=districts.to_crs(crs); municipal=d.geometry.union_all()
z,transform,vmin,vmax,demstats=ns['load_dem'](study,crs)
rgba=ns['dem_rgba'](z,vmin,vmax)
b=array_bounds(*z.shape,transform)
font=mpl.font_manager.findfont('Arial',fallback_to_default=False)
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial'],'font.size':7,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','figure.facecolor':'white','savefig.facecolor':'white',
 'axes.linewidth':.5,'text.color':'#30373A'})
fig=plt.figure(figsize=(83.737/25.4,101/25.4),dpi=160)
ax=fig.add_axes([.105,.245,.875,.745]);ax.set_facecolor('#F5F6F4')
ax.imshow(rgba,extent=[b[0],b[2],b[1],b[3]],origin='upper',interpolation='bilinear',zorder=1)
s.boundary.plot(ax=ax,color='#566268',linewidth=.5,alpha=.38,zorder=3)
d.boundary.plot(ax=ax,color='#303B40',linewidth=.7,alpha=.92,zorder=5)
gpd.GeoSeries([municipal],crs=crs).boundary.plot(ax=ax,color='#151C20',linewidth=1.05,zorder=6)
minx,miny,maxx,maxy=d.total_bounds
ax.set_xlim(minx-3500,maxx+3500);ax.set_ylim(miny-3500,maxy+3500);ax.set_aspect('equal',adjustable='box')
for sp in ax.spines.values():sp.set_linewidth(.5);sp.set_color('#303A3E')
ll=Transformer.from_crs('EPSG:4326',crs,always_xy=True)
# Every other longitude label (30-min data positions retained) avoids crowded ticks.
lon=[115.5,116.5,117.5];lat=[39.5,40,40.5,41]
ax.set_xticks([ll.transform(x,39.43)[0] for x in lon]);ax.set_xticklabels([ns['fmt_lon'](x) for x in lon],fontsize=7)
ax.set_yticks([ll.transform(115.42,y)[1] for y in lat]);ax.set_yticklabels([ns['fmt_lat'](y) for y in lat],fontsize=7,rotation=90,va='center')
ax.tick_params(direction='out',length=2,width=.5,pad=2,top=False,right=False)
ax.get_xticklabels()[0].set_ha('left'); ax.get_xticklabels()[-1].set_ha('right')
ns['add_north_arrow'](ax,.94,.93,.07,7.)
positions={
 'Yanqing':(115.97,40.48),'Huairou':(116.53,40.67),'Miyun':(116.99,40.49),
 'Pinggu':(117.25,40.16),'Shunyi':(116.70,40.17),'Changping':(116.16,40.25),
 'Mentougou':(115.80,40.02),'Fangshan':(115.78,39.72),'Daxing':(116.38,39.58),'Tongzhou':(116.91,39.81),
 'Haidian':(116.21,40.07),'Shijingshan':(115.77,39.89),'Fengtai':(116.08,39.67),
 'Xicheng':(116.10,39.82),'Dongcheng':(116.75,39.68),'Chaoyang':(116.88,39.98)}
labels=[];leaders=[];records=[]
for name,(lonv,latv) in positions.items():
    x,y=ll.transform(lonv,latv);geom=d.loc[d.district_en.eq(name),'geometry'].iloc[0]
    target=geom.representative_point();point=gpd.points_from_xy([x],[y])[0]
    leader=not geom.covers(point)
    if leader:
        line=ax.plot([target.x,x],[target.y,y],color='#30373A',lw=.5,zorder=19)[0]
        line.set_path_effects([pe.withStroke(linewidth=1.25,foreground='white',alpha=.98)])
        ax.plot(target.x,target.y,'o',color='#30373A',markersize=1.4,zorder=20)
        leaders.append(name)
    # White vector halo below a separate editable text layer.
    ax.text(x,y,name,fontsize=7,ha='center',va='center',zorder=21,
        path_effects=[pe.withStroke(linewidth=1.2,foreground='white',alpha=.95)])
    t=ax.text(x,y,name,fontsize=7,ha='center',va='center',zorder=22)
    labels.append(t);records.append({'district':name,'label_lonlat':[lonv,latv],'leader':leader,'target_inside_district':bool(geom.covers(target)),'target_projected':[target.x,target.y]})
# Scale stays inside southwest blank space, in projected metres.
x0=minx+4000;y0=miny+4000;height=1600
for i in range(2):ax.add_patch(Rectangle((x0+i*25000,y0),25000,height,facecolor='#111111' if i==0 else 'white',edgecolor='#111111',linewidth=.5,zorder=30))
for i in range(3):ax.text(x0+i*25000,y0-2500,f'{i*25}'+(' km' if i==2 else ''),ha='center',va='top',fontsize=7,zorder=31)
# Same legend information, moved out of the crowded map to preserve district labels.
handles=[Line2D([0],[0],color='#151C20',lw=1.05,label='Beijing municipal boundary'),
Line2D([0],[0],color='#303B40',lw=.7,label='District boundary (16)'),
Line2D([0],[0],color='#566268',lw=.5,label='Subdistrict boundary (343)')]
fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.105,.218),frameon=False,fontsize=7,
 handlelength=1.8,handletextpad=.6,labelspacing=.3,borderaxespad=0)
cax=fig.add_axes([.13,.04,.79,.025])
cb=fig.colorbar(mpl.cm.ScalarMappable(norm=Normalize(vmin=vmin,vmax=vmax),cmap=seq),cax=cax,orientation='horizontal',ticks=[vmin,500,1000,1500,2000,vmax])
cb.ax.set_xticklabels([str(int(x)) for x in [vmin,500,1000,1500,2000,vmax]],fontsize=7)
cb.ax.tick_params(width=.5,length=2,pad=2);cb.outline.set_linewidth(.5)
fig.text(.13,.078,'Elevation (m)',ha='left',va='bottom',fontsize=7)
fig.canvas.draw();ren=fig.canvas.get_renderer()
overlaps=[]
for ta,tb in combinations(labels,2):
    if ta.get_window_extent(ren).expanded(1.01,1.05).overlaps(tb.get_window_extent(ren).expanded(1.01,1.05)):overlaps.append([ta.get_text(),tb.get_text()])
outside=[]
for t in fig.findobj(mpl.text.Text):
    if not t.get_visible() or not t.get_text().strip():continue
    if t.axes is not None and not t.axes.axison and t not in t.axes.texts:continue
    bb=t.get_window_extent(ren)
    if bb.x0<-.5 or bb.y0<-.5 or bb.x1>fig.bbox.width+.5 or bb.y1>fig.bbox.height+.5:outside.append(t.get_text())
assert not overlaps, overlaps
assert not outside, outside
for ext in ['pdf','png','svg']:fig.savefig(ROOT/('Fig01_single_column.'+ext),dpi=600,bbox_inches=None,pad_inches=0,metadata=({'Creator':'Matplotlib','Author':'','Title':'Study area of Beijing'} if ext=='pdf' else None))
plt.close(fig)
with fitz.open(ROOT/'Fig01_single_column.pdf') as doc:
    page=doc[0];pix=page.get_pixmap(dpi=144,alpha=False);pix.save(ROOT/'QA/Fig01_native_144dpi.png')
    sizes=[sp['size'] for block in page.get_text('dict')['blocks'] for line in block.get('lines',[]) for sp in line['spans'] if sp['text'].strip()]
    fonts=[{'name':f[3],'embedded_bytes':len(doc.extract_font(f[0])[3])} for f in page.get_fonts(full=True)]
    pdfQA={'page_size_mm':[page.rect.width/72*25.4,page.rect.height/72*25.4], 'fonts':fonts,'font_range_pt':[min(sizes),max(sizes)],'raster_layers':len(page.get_images()),'vector_objects':len(page.get_drawings()),'metadata':doc.metadata,'district_names_in_pdf':{n:n in page.get_text() for n in positions}}
im=Image.open(ROOT/'QA/Fig01_native_144dpi.png').convert('RGB');im.convert('L').save(ROOT/'QA/Fig01_grayscale.png')
a=np.asarray(im,dtype=float)/255;lin=np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
matrix=np.array([[.367322,.860646,-.227968],[.280085,.672501,.047413],[-.011820,.042940,.968881]])
v=np.clip(lin@matrix.T,0,1);v=np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055)
Image.fromarray(np.uint8(np.clip(v,0,1)*255)).save(ROOT/'QA/Fig01_deuteranopia.png')
after={str(p):digest(p) for p in protected};assert before==after
qa={'scope':'layout only; no model/result recalculation','single_column_width_mm':83.737,'inputs_hash_unchanged':before==after,'streets':len(s),'districts':len(d),'display_crs':crs,'DEM':demstats,'palette':'original oslo_r trimmed .04-.93','label_records':records,'district_label_overlap_pairs':overlaps,'outside_canvas_text':outside,'PDF':pdfQA,'font_source':font,'Python':sys.executable,'Python_version':platform.python_version(),'artifact_sha256':{ext:digest(ROOT/('Fig01_single_column.'+ext)) for ext in ['pdf','png','svg']},'visual_QA':'pending'}
(ROOT/'QA/figure1_single_column_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
print(json.dumps({'overlaps':overlaps,'outside':outside,'pdf':pdfQA},ensure_ascii=False,indent=2))
